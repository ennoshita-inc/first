<?php
/**
 * ブログ一覧テンプレート (index.php)
 */
get_header();
?>

  <div class="archive-header">
    <div class="container">
      <h1 class="archive-header__title">コラム</h1>
      <p class="archive-header__description">人材育成・組織開発に関する知見をお届けします。</p>
    </div>
  </div>

  <?php ennoshita_breadcrumb(); ?>

  <div class="archive-content">
    <div class="container">
      <?php if (have_posts()) : ?>
        <div class="blog__grid">
          <?php while (have_posts()) : the_post(); ?>
            <?php get_template_part('template-parts/content', 'card'); ?>
          <?php endwhile; ?>
        </div>

        <div class="pagination">
          <?php
          the_posts_pagination([
            'mid_size'  => 2,
            'prev_text' => '&laquo;',
            'next_text' => '&raquo;',
          ]);
          ?>
        </div>
      <?php else : ?>
        <?php get_template_part('template-parts/content', 'none'); ?>
      <?php endif; ?>
    </div>
  </div>

<?php get_footer(); ?>
