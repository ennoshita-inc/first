# CLAUDE.md — endock（組織活力調査）LP・WordPressテーマ内

このファイルは LP 専用フォルダ（`wp-content/themes/ennoshita/lp-endock/`）内の指示書です。
**親フォルダの `CLAUDE.md`（テーマ全体の指示書）と併せて読まれます。**

親 CLAUDE.md の規定（プロジェクト概要・サイトの目的・川路隆志の強み等）は引き続き有効。
このファイルは LP 制作時の**追加ルール**を定義します。

---

## 🎯 このフォルダの目的

株式会社えんのしたの新サービス「**endock（組織活力調査）**」のランディングページ（LP）を
**既存テーマ・既存ページに影響を与えない形で**新規作成する。

### サービスブランド
- **ブランド名**: endock（エンドック）
- **正式サービス名**: 組織活力調査
- **ブランドの由来（推察）**: 「縁の下＋dock（ドック）」 = 組織の健康診断的な意味合い
- **URL**: `https://ennoshita.co.jp/endock/`

### 訪問動線（想定）
1. 既存サイト（ennoshita.co.jp）のサービスページ等から CTA でリンク
2. または、エージェント経由・営業資料から直接 LP URL（`/endock/`）へ
3. LP で endock の価値を理解 → お問い合わせ・資料請求

---

## 🔒 既存テーマへの影響ゼロ原則（最優先）

### 触ってはいけないファイル
- ❌ `wp-content/themes/ennoshita/style.css`（87KB・既存テーマの心臓）
- ❌ `wp-content/themes/ennoshita/header.php`（全ページ共通ヘッダー）
- ❌ `wp-content/themes/ennoshita/footer.php`（全ページ共通フッター）
- ❌ 既存の `page-*.php`（page-about, page-service, page-contact 等）

### 完全に新規作成するファイル
- ✅ `wp-content/themes/ennoshita/page-endock.php`（LP テンプレート）
- ✅ `wp-content/themes/ennoshita/lp-endock/lp-endock.css`（LP専用CSS）
- ✅ `wp-content/themes/ennoshita/lp-endock/tokens.css`（design-system 変数）
- ✅ `wp-content/themes/ennoshita/lp-endock/assets/logo-primary.png`

### functions.php への変更
- 理想的にはゼロ。page-endock.php がすべての CSS/Font を `<link>` で自前読み込みするため。

---

## 🎨 デザインシステム参照（必須）

### えんのしたデザインシステム v1.3
- **GitHub**: https://github.com/ennoshita-inc/design-system
- **OneDrive**: `~/Library/CloudStorage/OneDrive-個人用/ドキュメント/Magic Briefcase/GitHub/design-system/`

### 主要参照ファイル
1. `SPECIFICATION_v1.3.md` — カラー・フォント・余白・コンポーネントの仕様
2. `patterns/proposal/4x3/proposal_4x3_v1.3.html` — コンポーネント実装例
3. `assets/logo-primary.png` — 会社ロゴ

---

## 🎨 デザイントークン（CSS変数）

`tokens.css` ファイルとして、`.lp-endock` スコープで定義：

```css
.lp-endock {
  /* 主役色 */
  --enji: #8B2332;
  --enji-deep: #6E1A27;
  --enji-line: #8B233266;
  --enji-soft: #8B233222;

  /* 脇役色 */
  --kincha: #D4A574;
  --kincha-deep: #B8894F;
  --kincha-soft: #FEF9F0;

  /* 背景・紙系 */
  --paper: #FAF9F7;
  --paper-warm: #F3F1EC;
  --line: #DDD7CC;

  /* 文字色 */
  --ink: #1A1A1A;
  --text: #3A3A38;
  --mute: #6B6B68;

  /* フォント */
  --display: "Noto Serif JP", "Source Han Serif", "源ノ明朝", "ヒラギノ明朝 ProN", "Yu Mincho", serif;
  --body: "Noto Sans JP", "Source Han Sans", "源ノ角ゴシック", "Hiragino Sans", "Hiragino Kaku Gothic ProN", "Meiryo", sans-serif;
  --mono: "Inter", "Helvetica Neue", "Arial", sans-serif;
}
```

⚠️ **重要**：`:root` ではなく `.lp-endock` スコープで定義する。既存テーマの `:root` と競合しない。

---

## 🏗️ LP テンプレート（page-endock.php）の骨格

```php
<?php
/**
 * Template Name: endock LP
 *
 * カスタムテンプレート。固定ページ「endock」（slug: endock）に適用する。
 * 既存テーマの header.php / footer.php は使わず、LP専用に最小構成で作成。
 */
?><!DOCTYPE html>
<html lang="ja" <?php language_attributes(); ?>>
<head>
  <meta charset="<?php bloginfo('charset'); ?>">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>endock 組織活力調査｜株式会社えんのした</title>
  <meta name="description" content="endock（エンドック）は、株式会社えんのしたが提供する組織活力調査サービス。データで組織の現状を可視化し、本質的な変革をサポートします。">

  <!-- OGP（SNSシェア対応） -->
  <meta property="og:title" content="endock 組織活力調査｜株式会社えんのした">
  <meta property="og:description" content="組織の活力をデータで可視化し、本質的な変革を支援する組織健診サービス">
  <meta property="og:type" content="website">
  <meta property="og:url" content="https://ennoshita.co.jp/endock/">

  <!-- Google Fonts（LPでのみ読み込み・既存テーマには影響なし） -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+JP:wght@400;500;700;900&family=Noto+Serif+JP:wght@500;700;900&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">

  <!-- LP専用CSS -->
  <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/lp-endock/tokens.css">
  <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/lp-endock/lp-endock.css">

  <?php wp_head(); ?>
</head>
<body class="lp-endock">
  <!-- セクション群 -->
  <?php wp_footer(); ?>
</body>
</html>
```

⚠️ **重要なポイント**：
1. **既存テーマの `get_header()` / `get_footer()` を使わない** → 既存ヘッダー・フッターの干渉を避ける
2. **`<body class="lp-endock">`** → LP固有のクラスでスコープ分離
3. **`get_template_directory_uri()`** で確実にテーマディレクトリ参照
4. **`wp_head()` / `wp_footer()`** は WordPress プラグインとの互換性のため必須
5. **`<title>` / `<meta description>` / OGP** は SEO のため丁寧に設定

---

## 🎨 LP専用CSS（lp-endock.css）の構造

すべてのスタイルを `.lp-endock` 下にネストして既存 `style.css` と完全に分離する。
セクション・コンポーネントの詳細は `lp-endock.css` を参照。

---

## 📋 実装フロー

### Step 1: フォルダ・ファイル作成
```
wp-content/themes/ennoshita/lp-endock/
├── CLAUDE.md           ← このファイル
├── README.md
├── tokens.css
├── lp-endock.css
└── assets/
    ├── logo-primary.png （design-system からコピー済）
    └── images/
```

### Step 2: page-endock.php を作成
- 上記の骨格テンプレートをベースに
- セクションごとに `<section class="lp-endock__...">` で構成

### Step 3: WordPress 管理画面で固定ページを作成
1. 管理画面 → 固定ページ → 新規追加
2. タイトル：「endock」（または「endock 組織活力調査」）
3. **パーマリンク（slug）：`endock`**
4. 「ページ属性」→「テンプレート」で「**endock LP**」を選択
5. 公開

→ URL：`https://ennoshita.co.jp/endock/`

### Step 4: ZIP デプロイ（既存ワークフロー通り）
リポジトリルートで zip 化 → WP管理画面 → テーマ → 新規追加 → ZIPアップロード → 有効化

### Step 5: 動作確認
- ✅ LP の表示確認（PC/スマホ/タブレット）
- ✅ 既存ページに影響がないか確認（about/, service/, contact/ など）
- ✅ Google Fonts が二重読み込みされていないか確認
- ✅ お問い合わせフォームへのリンクが機能するか確認

---

## 🚫 やってはいけないこと

- ❌ 既存 `style.css` への変更
- ❌ 既存 `header.php` / `footer.php` への変更
- ❌ 既存 `page-*.php` への変更
- ❌ `:root` での CSS変数定義（既存テーマと競合の可能性）
- ❌ 既存 functions.php の編集（必要なら最小限・要相談）
- ❌ 既存と異なるフォントの追加読み込み（重複読み込み）
- ❌ `!important` の乱用（必要な箇所のみ慎重に）

---

## ✅ 制作前チェックリスト

- [ ] design-system/SPECIFICATION_v1.3.md を読んだ
- [ ] design-system/patterns/proposal/4x3/proposal_4x3_v1.3.html を確認した
- [ ] 既存テーマの style.css 内で `.lp-endock` クラスが使われていないことを確認
- [ ] tokens.css を `.lp-endock` スコープで定義
- [ ] page-endock.php に `Template Name: endock LP` コメントがある
- [ ] body に class="lp-endock" を付与
- [ ] レスポンシブ対応（clamp() / @media）を組み込む
- [ ] 会社情報は正式表記（〒700-0826 岡山市北区磨屋町10-20 磨屋町ビル8階）
- [ ] OGP メタタグを設定（SNSシェア対応）

---

## 🎨 endock のブランドメッセージ案

LP コピーライティングの参考案（採用判断は川路さんが最終決定）：

### キャッチコピー候補
- 「あなたの組織は、本当に活きているか。」
- 「数字で見えない、活力を診る。」
- 「組織の声に、データで耳を傾ける。」
- 「えんのしたが行う、組織の健診。」

### サブメッセージ候補
- 「制度や評価よりも先に、日々の対話の質が組織の本当の強さを決める。」
- 「endock は、見えにくい『組織の活力』を可視化する診断ツールです。」

### endock の価値訴求（3つの柱）

候補1：
1. **可視化** — 数字で見えにくい組織の状態をデータで把握
2. **対話の起点** — 調査結果が組織内の建設的な対話を生む
3. **継続的な進捗管理** — PDS サイクルで効果を測定し続ける

候補2：
1. **科学的アプローチ** — エビデンスベースの設問設計
2. **伴走型支援** — 調査だけでなく、結果を行動に変える支援
3. **長期パートナーシップ** — 一過性の調査でない、継続的な関係

→ 川路さんと相談して、最適な3点を選定してください。

---

## 🎨 LP固有のデザイン方針

### 仕様書1.1 哲学を Web に翻訳

```
スライド版（v1.3）           LP版（endock）
─────────────────             ─────────────────
1024×768 固定          →     レスポンシブ（モバイル優先）
E4ヘッダー4px帯        →     控えめなヘッダー（線・パディング）
点線フッタ             →     会社情報のしっかりしたフッター
1スライド1メッセージ   →     1スクロール1セクション
```

### LP のセクション構成（推奨）

1. **ヘッダー**（最小限・ロゴのみ）
2. **ヒーロー**（キャッチコピー + サブメッセージ + CTA）
3. **問題提起**（読者が抱える課題）
4. **endock の3つの特徴**（THREE_PILLARS 風・数字を大きく）
5. **調査プロセス**（WORK の 2×2 流用 / 4ステップ）
6. **引用・哲学**（QUOTE_HERO 風・えんのしたの哲学）
7. **従来との違い**（COMPARISON 風）
8. **料金・メニュー**（任意・TABLE 風）
9. **CTA**（強調ボックス）
10. **会社情報フッター**（design-system 裏表紙構造）

### モバイル優先設計

- まずスマホで美しく → タブレット → PCの順で確認
- フォントは `clamp()` でレスポンシブに
- 横スクロール禁止（`overflow-x: hidden`）
- タップ領域は最低 44×44px

---

## 📚 参考リソース

質問があれば以下を参照：
- 親 CLAUDE.md（テーマ全体の方針・川路隆志の強み）
- design-system/SPECIFICATION_v1.3.md（デザイン仕様）
- design-system/patterns/（コンポーネント実装例）
- WEBSITE-IMPROVEMENT-PLAN.md（既存サイトの改善計画）

---

## 🌟 endock の意味（覚え書き）

ブランド名 **endock** は、おそらく以下の意味合いを持つ命名：

- **en** = 縁（えん）/ 株式会社えんのしたの「えん」
- **dock** = 船舶のドック・人間ドック → **健康診断**のメタファー

→ 「組織の健診ステーション」「縁の下の組織ドック」というブランドイメージ。
このメタファーをLPデザイン・コピー全体で生かすと、訴求が一貫する。
