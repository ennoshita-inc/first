<?php
/**
 * Template Name: endock LP
 *
 * 組織活力調査 endock のランディングページ専用テンプレート。
 *
 * - 既存テーマの header.php / footer.php は使わず、LP専用に最小構成で作成
 * - LP関連の付随ファイルは wp-content/themes/ennoshita/lp-endock/ に配置
 * - <body class="lp-endock"> によるスコープ分離で既存 style.css に影響なし
 *
 * Design System v1.3 (株式会社えんのした) 準拠
 */

if (!defined('ABSPATH')) { exit; }

$theme_uri    = get_template_directory_uri();
$contact_url  = esc_url(home_url('/contact/'));
$about_url    = esc_url(home_url('/about/'));
$home_url     = esc_url(home_url('/'));
?><!DOCTYPE html>
<html lang="ja" <?php language_attributes(); ?>>
<head>
  <meta charset="<?php bloginfo('charset'); ?>">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="format-detection" content="telephone=no">

  <title>endock 組織活力調査 ｜ 株式会社えんのした</title>
  <meta name="description" content="endock（エンドック）は、株式会社えんのしたが提供する組織活力調査サービス。8カテゴリ60問の学術的設問とインタラクティブダッシュボードで組織の現状を可視化し、本質的な変革を支援します。">

  <!-- OGP（SNSシェア対応） -->
  <meta property="og:site_name" content="株式会社えんのした">
  <meta property="og:title" content="endock 組織活力調査 ｜ 株式会社えんのした">
  <meta property="og:description" content="組織の活力をデータで可視化し、本質的な変革を支援する組織健診サービス。">
  <meta property="og:type" content="website">
  <meta property="og:url" content="<?php echo esc_url(home_url('/endock/')); ?>">
  <meta property="og:locale" content="ja_JP">
  <meta name="twitter:card" content="summary_large_image">

  <link rel="canonical" href="<?php echo esc_url(home_url('/endock/')); ?>">

  <!-- Google Fonts -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+JP:wght@400;500;700;900&family=Noto+Serif+JP:wght@500;700;900&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">

  <!-- LP専用CSS -->
  <link rel="stylesheet" href="<?php echo esc_url($theme_uri); ?>/lp-endock/tokens.css">
  <link rel="stylesheet" href="<?php echo esc_url($theme_uri); ?>/lp-endock/lp-endock.css">

  <?php wp_head(); ?>
</head>
<body <?php body_class('lp-endock'); ?>>

<!-- ============================================================
     1. ヘッダー（最小限・ロゴのみ）
     ============================================================ -->
<header class="lp-endock__header" role="banner">
  <div class="lp-endock__header-inner">
    <a href="<?php echo $home_url; ?>" class="lp-endock__brand" aria-label="株式会社えんのした トップへ">
      <img class="lp-endock__logo" src="<?php echo esc_url($theme_uri); ?>/lp-endock/assets/logo-primary.png" alt="株式会社えんのした">
    </a>
    <span class="lp-endock__header-meta">Organizational Vitality Survey</span>
  </div>
</header>

<main id="main-content">

<!-- ============================================================
     2. ヒーロー
     ============================================================ -->
<section class="lp-endock__hero" aria-labelledby="hero-title">
  <div class="lp-endock__inner">
    <p class="lp-endock__hero-label">ENDOCK ─ 組織活力調査</p>
    <h1 class="lp-endock__title" id="hero-title">
      あなたの組織は、<br>
      本当に<em>活きて</em>いるか。
    </h1>
    <p class="lp-endock__lead">
      数字で見えにくい「組織の活力」を、データで可視化する。<br>
      えんのしたの組織健診サービス、それが <strong>endock</strong> です。
    </p>

    <a href="#contact" class="lp-endock__cta-primary">資料請求・無料相談へ</a>

    <div class="lp-endock__hero-stats" aria-label="endockの基本仕様">
      <div class="lp-endock__hero-stat">
        <span class="lp-endock__hero-stat-num">60</span>
        <span class="lp-endock__hero-stat-label">標準設問数</span>
      </div>
      <div class="lp-endock__hero-stat">
        <span class="lp-endock__hero-stat-num">8</span>
        <span class="lp-endock__hero-stat-label">診断カテゴリ</span>
      </div>
      <div class="lp-endock__hero-stat">
        <span class="lp-endock__hero-stat-num">4</span>
        <span class="lp-endock__hero-stat-label">集計軸</span>
      </div>
      <div class="lp-endock__hero-stat">
        <span class="lp-endock__hero-stat-num">7</span>
        <span class="lp-endock__hero-stat-label">ダッシュボードタブ</span>
      </div>
    </div>
  </div>
</section>

<!-- ============================================================
     3. 問題提起
     ============================================================ -->
<section class="lp-endock__section lp-endock__section--warm" aria-labelledby="problem-title">
  <div class="lp-endock__inner">
    <header class="lp-endock__section-header">
      <p class="lp-endock__section-eyebrow">PROBLEM</p>
      <h2 class="lp-endock__section-title" id="problem-title">
        こんな課題を、感じていませんか。
      </h2>
      <div class="lp-endock__section-rule"></div>
      <p class="lp-endock__section-desc">
        多くの企業が「なんとなく」感じている組織課題。<br>
        endock は、それを定量データとして可視化します。
      </p>
    </header>

    <div class="lp-endock__problem-grid">
      <div class="lp-endock__problem-card">
        <h4>社員の本音が見えない</h4>
        <p>日常会話や面談では本音が出にくい。経営陣への不満や将来不安は、退職面談で初めて表面化することも。</p>
      </div>
      <div class="lp-endock__problem-card">
        <h4>離職の原因がわからない</h4>
        <p>「給与」「人間関係」「成長実感」——離職要因は複合的。感覚的な対策では根本解決に至らない。</p>
      </div>
      <div class="lp-endock__problem-card">
        <h4>部門ごとの温度差</h4>
        <p>同じ会社でも部門によって「働きやすさ」は大きく異なる。全社一律の施策では効果にムラが出る。</p>
      </div>
      <div class="lp-endock__problem-card">
        <h4>施策の効果が測れない</h4>
        <p>研修やイベントを実施しても「やった感」だけで終わっていないか。投資対効果の説明が難しい。</p>
      </div>
    </div>

    <div class="lp-endock__solution-box">
      <h3>endock が、それを解きほぐす。</h3>
      <p>
        endock は、組織の状態を <strong>8つのカテゴリ × 4つの集計軸</strong> で多角的に定量化する組織健診ツール。
        単なるアンケートではなく、調査結果を <strong>インタラクティブなダッシュボード</strong> として可視化し、
        えんのしたが具体的な組織開発施策へと一気通貫で接続します。<br><br>
        「何が問題か」だけでなく「どこから手をつけるべきか」まで、データに基づく意思決定を可能にします。
      </p>
    </div>
  </div>
</section>

<!-- ============================================================
     4. endock の3つの特徴（PILLARS）
     ============================================================ -->
<section class="lp-endock__section" aria-labelledby="pillars-title">
  <div class="lp-endock__inner">
    <header class="lp-endock__section-header">
      <p class="lp-endock__section-eyebrow">FEATURES</p>
      <h2 class="lp-endock__section-title" id="pillars-title">
        endock を、<em>endock</em> たらしめる<br>3つの特徴。
      </h2>
      <div class="lp-endock__section-rule"></div>
      <p class="lp-endock__section-desc">
        「調査して終わり」にしない。<br>
        データ収集から施策提案まで、組織変革のサイクルを支える設計です。
      </p>
    </header>

    <div class="lp-endock__pillars">
      <article class="lp-endock__pillar">
        <span class="lp-endock__pillar-num">01</span>
        <div class="lp-endock__pillar-rule"></div>
        <h3>学術的根拠に基づく<br>設問設計</h3>
        <p>組織行動論・経営学の理論をベースに、8カテゴリ60問を体系的に構成。「何を測っているか」が明確だから、結果の解釈と施策への接続がぶれません。</p>
      </article>

      <article class="lp-endock__pillar">
        <span class="lp-endock__pillar-num">02</span>
        <div class="lp-endock__pillar-rule"></div>
        <h3>インタラクティブな<br>ダッシュボード</h3>
        <p>レーダーチャート・トレンド分析・部門別比較・ヒートマップ等を7タブで即座に確認。経営会議にそのまま使えるレベルの分析レポートを納品します。</p>
      </article>

      <article class="lp-endock__pillar">
        <span class="lp-endock__pillar-num">03</span>
        <div class="lp-endock__pillar-rule"></div>
        <h3>結果に基づく<br>具体的な施策提案</h3>
        <p>診断データと組織開発の専門知見を掛け合わせ、CMBO導入・リーダーシップ開発・1on1の質向上など、御社の課題に最適化した施策をご提案・伴走します。</p>
      </article>
    </div>
  </div>
</section>

<!-- ============================================================
     5. 診断カテゴリ
     ============================================================ -->
<section class="lp-endock__section lp-endock__section--warm" aria-labelledby="cat-title">
  <div class="lp-endock__inner">
    <header class="lp-endock__section-header">
      <p class="lp-endock__section-eyebrow">CATEGORIES</p>
      <h2 class="lp-endock__section-title" id="cat-title">
        4つの軸で、組織を立体的に診る。
      </h2>
      <div class="lp-endock__section-rule"></div>
      <p class="lp-endock__section-desc">
        「会社」「上司」「同僚」「仕事」の4軸 × 8カテゴリで、<br>
        組織の健康状態を多角的に把握します。
      </p>
    </header>

    <div class="lp-endock__cat-axes" aria-label="4つの集計軸">
      <div class="lp-endock__cat-axis">
        <div class="lp-endock__cat-axis-name">会社</div>
        <div class="lp-endock__cat-axis-q">経営・制度・環境</div>
      </div>
      <div class="lp-endock__cat-axis">
        <div class="lp-endock__cat-axis-name">上司</div>
        <div class="lp-endock__cat-axis-q">マネジメント・関係性</div>
      </div>
      <div class="lp-endock__cat-axis">
        <div class="lp-endock__cat-axis-name">同僚</div>
        <div class="lp-endock__cat-axis-q">志向・チーム力</div>
      </div>
      <div class="lp-endock__cat-axis">
        <div class="lp-endock__cat-axis-name">仕事</div>
        <div class="lp-endock__cat-axis-q">目標・充実度</div>
      </div>
    </div>

    <div class="lp-endock__cat-grid">
      <article class="lp-endock__cat-card">
        <h4>A. 経営（トップマネジメント）</h4>
        <p>経営方針の浸透、経営層への信頼、変革意欲、将来性、現場感覚を測定。</p>
        <span class="lp-endock__cat-card-tag">軸：会社 ／ 9問</span>
      </article>
      <article class="lp-endock__cat-card">
        <h4>B. 人事制度</h4>
        <p>評価の公正性、待遇・報酬、コンプライアンス、人材育成機会を多面的に測定。</p>
        <span class="lp-endock__cat-card-tag">軸：会社 ／ 14問</span>
      </article>
      <article class="lp-endock__cat-card">
        <h4>C. 労働環境</h4>
        <p>情報伝達、職場の活気、業務負荷、効率性など、働く環境の質を測定。</p>
        <span class="lp-endock__cat-card-tag">軸：会社 ／ 9問</span>
      </article>
      <article class="lp-endock__cat-card">
        <h4>D. リーダーシップ</h4>
        <p>上司の課題把握力、施策実行力、キャリア対話の実践度を測定。</p>
        <span class="lp-endock__cat-card-tag">軸：上司 ／ 3問</span>
      </article>
      <article class="lp-endock__cat-card">
        <h4>E. 対人関係（上司）</h4>
        <p>フィードバックの質、面談の雰囲気、信頼関係、育成姿勢を測定。</p>
        <span class="lp-endock__cat-card-tag">軸：上司 ／ 6問</span>
      </article>
      <article class="lp-endock__cat-card">
        <h4>F. 仕事の志向</h4>
        <p>顧客志向、チャレンジ意欲、責任感など、仕事に対する姿勢を測定。</p>
        <span class="lp-endock__cat-card-tag">軸：同僚 ／ 3問</span>
      </article>
      <article class="lp-endock__cat-card">
        <h4>G. 組織連帯感</h4>
        <p>チーム内コミュニケーション、相互成長、結束力、部門間連携を測定。</p>
        <span class="lp-endock__cat-card-tag">軸：同僚 ／ 7問</span>
      </article>
      <article class="lp-endock__cat-card">
        <h4>H. 個人特性（仕事）</h4>
        <p>目標納得度、適材適所の実感、成長実感、モチベーション、定着意向を測定。</p>
        <span class="lp-endock__cat-card-tag">軸：仕事 ／ 9問</span>
      </article>
    </div>
  </div>
</section>

<!-- ============================================================
     6. 引用・哲学
     ============================================================ -->
<section class="lp-endock__quote" aria-label="えんのしたの哲学">
  <div class="lp-endock__inner lp-endock__inner--narrow">
    <blockquote class="lp-endock__quote-text">
      縁の下となり、<br>
      新たな価値を生み出す。
    </blockquote>
    <p class="lp-endock__quote-author">えんのした流・組織開発の哲学</p>
  </div>
</section>

<!-- ============================================================
     7. 調査の流れ（プロセス）
     ============================================================ -->
<section class="lp-endock__section" aria-labelledby="process-title">
  <div class="lp-endock__inner">
    <header class="lp-endock__section-header">
      <p class="lp-endock__section-eyebrow">PROCESS</p>
      <h2 class="lp-endock__section-title" id="process-title">
        調査の、流れ。
      </h2>
      <div class="lp-endock__section-rule"></div>
      <p class="lp-endock__section-desc">
        お申し込みからダッシュボード納品、施策提案まで、<br>
        およそ <strong>4〜6週間</strong> で完了します。
      </p>
    </header>

    <div class="lp-endock__process">
      <div class="lp-endock__step">
        <div class="lp-endock__step-num">STEP 01</div>
        <h4>事前ヒアリング</h4>
        <div class="lp-endock__step-duration">1〜2日</div>
        <p>部署構成・職位体系・調査目的を確認し、カスタマイズ箇所を特定します。</p>
      </div>
      <div class="lp-endock__step">
        <div class="lp-endock__step-num">STEP 02</div>
        <h4>調査フォーム構築・実施</h4>
        <div class="lp-endock__step-duration">2〜3週間</div>
        <p>Webアンケートを構築し全従業員に配信。完全匿名制で率直な回答を促進します。</p>
      </div>
      <div class="lp-endock__step">
        <div class="lp-endock__step-num">STEP 03</div>
        <h4>分析・ダッシュボード作成</h4>
        <div class="lp-endock__step-duration">1〜2週間</div>
        <p>回収データを集計・換算し、7タブのインタラクティブダッシュボードを生成します。</p>
      </div>
      <div class="lp-endock__step">
        <div class="lp-endock__step-num">STEP 04</div>
        <h4>報告会・施策提案</h4>
        <div class="lp-endock__step-duration">90分／対面・オンライン</div>
        <p>経営層・人事担当者へ報告。データに基づく具体的な施策提案書をお渡しします。</p>
      </div>
    </div>
  </div>
</section>

<!-- ============================================================
     8. 比較セクション（COMPARISON）
     ============================================================ -->
<section class="lp-endock__section lp-endock__section--warm" aria-labelledby="compare-title">
  <div class="lp-endock__inner">
    <header class="lp-endock__section-header">
      <p class="lp-endock__section-eyebrow">COMPARISON</p>
      <h2 class="lp-endock__section-title" id="compare-title">
        従来の調査と、何が違うのか。
      </h2>
      <div class="lp-endock__section-rule"></div>
    </header>

    <div class="lp-endock__compare">
      <div class="lp-endock__compare-card">
        <p class="lp-endock__compare-label">従来の組織調査</p>
        <h4>「やった感」で終わりやすい</h4>
        <ul>
          <li>設問数が多すぎて回答者の負担が大きい</li>
          <li>分厚い報告書を渡されて読み解けない</li>
          <li>毎年違う設問で経年比較ができない</li>
          <li>結果が現場の行動に反映されない</li>
          <li>調査と組織開発支援が別々のベンダー</li>
        </ul>
      </div>

      <div class="lp-endock__compare-card lp-endock__compare-card--accent">
        <p class="lp-endock__compare-label">endock（えんのした）</p>
        <h4>調査を、行動につなげる</h4>
        <ul>
          <li>60問・回答約20分。負担と精度のバランス設計</li>
          <li>インタラクティブダッシュボードで誰でも読める</li>
          <li>5年間の経年変化を同じ軸で追跡可能</li>
          <li>結果に基づく具体的な施策をハンズオンで支援</li>
          <li>診断〜施策実行まで一気通貫で伴走</li>
        </ul>
      </div>
    </div>
  </div>
</section>

<!-- ============================================================
     9. 最終CTA
     ============================================================ -->
<section class="lp-endock__final-cta" id="contact" aria-labelledby="cta-title">
  <div class="lp-endock__inner lp-endock__inner--narrow">
    <h2 class="lp-endock__final-cta-title" id="cta-title">
      まず、一度<br>話を聞いてみませんか。
    </h2>
    <p class="lp-endock__final-cta-desc">
      導入規模・調査範囲に応じて、個別にお見積りいたします。<br>
      30名規模の中小企業から、複数拠点を持つ中堅企業まで対応可能。<br>
      売り込みではなく、御社の組織課題を一緒に整理する場としてお使いください。
    </p>
    <div class="lp-endock__final-cta-actions">
      <a href="<?php echo $contact_url; ?>" class="lp-endock__cta-primary">お問い合わせはこちら</a>
      <a href="<?php echo $about_url; ?>" class="lp-endock__cta-secondary">えんのしたについて</a>
    </div>
    <p class="lp-endock__assurance">— 営業電話・しつこいご連絡は、いたしません。</p>
  </div>
</section>

</main>

<!-- ============================================================
     10. フッター（会社情報）
     ============================================================ -->
<footer class="lp-endock__footer" role="contentinfo">
  <div class="lp-endock__footer-inner">
    <div class="lp-endock__footer-brand">
      <img src="<?php echo esc_url($theme_uri); ?>/lp-endock/assets/logo-primary.png" alt="株式会社えんのした">
    </div>
    <div class="lp-endock__footer-info">
      <p class="lp-endock__footer-name">株式会社えんのした ／ 代表取締役 川路 隆志</p>
      <p>〒700-0826　岡山市北区磨屋町10-20　磨屋町ビル8階</p>
      <p>TEL: 086-237-4455 ／ FAX: 086-899-6496</p>
      <p>
        <a href="https://www.ennoshita.co.jp/">www.ennoshita.co.jp</a>
        ／
        <a href="mailto:kawaji@ennoshita.co.jp">kawaji@ennoshita.co.jp</a>
      </p>
    </div>
  </div>
  <p class="lp-endock__footer-copy">© <?php echo esc_html(date_i18n('Y')); ?> ENNOSHITA Inc.</p>
</footer>

<?php wp_footer(); ?>
</body>
</html>
