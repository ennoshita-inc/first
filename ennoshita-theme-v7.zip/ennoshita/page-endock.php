<?php
/**
 * Template Name: endock LP
 *
 * 組織活力調査 endock のランディングページ専用テンプレート。
 *
 * - 既存テーマの header.php / footer.php は使わず、LP専用に最小構成で作成
 * - LP関連の付随ファイルは wp-content/themes/ennoshita/lp-endock/ に配置
 * - <body class="lp-endock"> によるスコープ分離で既存 style.css に影響なし
 * - サンプルダッシュボードを iframe で実物プレビューとして埋め込み
 */

if (!defined('ABSPATH')) { exit; }

$theme_uri    = get_template_directory_uri();
$contact_url  = esc_url(home_url('/contact/'));
$about_url    = esc_url(home_url('/about/'));
$home_url     = esc_url(home_url('/'));
$dashboard_url = esc_url($theme_uri . '/lp-endock/dashboard-sample.html');
?><!DOCTYPE html>
<html lang="ja" <?php language_attributes(); ?>>
<head>
  <meta charset="<?php bloginfo('charset'); ?>">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="format-detection" content="telephone=no">

  <title>組織活力調査 endock（エンドック）｜株式会社えんのした</title>
  <meta name="description" content="endock（エンドック）は、組織の活力をデータで可視化する組織健診サービス。8カテゴリ60問の学術的設問とインタラクティブダッシュボードで、組織の現状から具体的な施策提案まで、株式会社えんのしたが一気通貫で支援します。">

  <!-- OGP -->
  <meta property="og:site_name" content="株式会社えんのした">
  <meta property="og:title" content="組織活力調査 endock｜株式会社えんのした">
  <meta property="og:description" content="組織の活力をデータで可視化する、えんのしたの組織健診サービス。">
  <meta property="og:type" content="website">
  <meta property="og:url" content="<?php echo esc_url(home_url('/endock/')); ?>">
  <meta property="og:locale" content="ja_JP">
  <meta name="twitter:card" content="summary_large_image">
  <link rel="canonical" href="<?php echo esc_url(home_url('/endock/')); ?>">

  <!-- Google Fonts -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+JP:wght@300;400;500;700;900&family=Noto+Serif+JP:wght@500;700;900&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">

  <!-- LP専用CSS（既存style.cssには触れない） -->
  <link rel="stylesheet" href="<?php echo esc_url($theme_uri); ?>/lp-endock/tokens.css">
  <link rel="stylesheet" href="<?php echo esc_url($theme_uri); ?>/lp-endock/lp-endock.css">

  <?php wp_head(); ?>
</head>
<body <?php body_class('lp-endock'); ?>>

<!-- ============================================================
     1. LP ヘッダー（最小・スティッキー）
     ============================================================ -->
<header class="lp-endock__header" role="banner">
  <div class="lp-endock__header-inner">
    <a href="<?php echo $home_url; ?>" class="lp-endock__brand" aria-label="株式会社えんのした トップへ戻る">
      <img class="lp-endock__brand-logo" src="<?php echo esc_url($theme_uri); ?>/lp-endock/assets/logo-primary.png" alt="株式会社えんのした">
      <span class="lp-endock__brand-back">← トップへ戻る</span>
    </a>
    <a href="#contact" class="lp-endock__header-cta">お問い合わせ</a>
  </div>
</header>

<main id="main-content">

<!-- ============================================================
     2. ヒーロー
     ============================================================ -->
<section class="lp-endock__hero" aria-labelledby="hero-title">
  <div class="lp-endock__hero-inner">
    <div class="lp-endock__hero-eyebrow reveal">ENDOCK ─ 組織活力調査</div>
    <h1 class="lp-endock__hero-title reveal" id="hero-title">
      組織の声を、<em>データで聴く。</em><br>
      えんのしたの組織健診。
    </h1>
    <p class="lp-endock__hero-lead reveal reveal--delay-1">
      数字で見えにくい「組織の活力」を、<strong>8カテゴリ・60問</strong>の調査と
      <strong>インタラクティブダッシュボード</strong>で可視化。<br>
      調査して終わりではなく、結果に基づく具体的な施策提案までを一気通貫で支援します。
    </p>

    <div class="lp-endock__hero-actions reveal reveal--delay-2">
      <a href="#dashboard" class="lp-endock__btn lp-endock__btn--primary">
        実物のダッシュボードを見る <span class="lp-endock__btn-arrow">↓</span>
      </a>
      <a href="#contact" class="lp-endock__btn lp-endock__btn--ghost">
        無料相談・お問い合わせ
      </a>
    </div>

    <div class="lp-endock__stats reveal reveal--delay-3" aria-label="endockの基本仕様">
      <div class="lp-endock__stat">
        <span class="lp-endock__stat-num">60</span>
        <span class="lp-endock__stat-label">標準設問数</span>
      </div>
      <div class="lp-endock__stat">
        <span class="lp-endock__stat-num">8</span>
        <span class="lp-endock__stat-label">診断カテゴリ</span>
      </div>
      <div class="lp-endock__stat">
        <span class="lp-endock__stat-num">4</span>
        <span class="lp-endock__stat-label">集計軸</span>
      </div>
      <div class="lp-endock__stat">
        <span class="lp-endock__stat-num">7</span>
        <span class="lp-endock__stat-label">ダッシュボードタブ</span>
      </div>
    </div>
  </div>
</section>

<!-- ============================================================
     3. 課題提起
     ============================================================ -->
<section class="lp-endock__section lp-endock__section--warm" aria-labelledby="problem-title">
  <div class="lp-endock__container">
    <header class="lp-endock__section-header reveal">
      <span class="lp-endock__eyebrow">PROBLEM</span>
      <h2 class="lp-endock__h2" id="problem-title">こんな課題を、感じていませんか。</h2>
      <span class="lp-endock__rule"></span>
      <p class="lp-endock__section-desc">
        多くの企業が「なんとなく」感じている組織課題。<br>endockは、それを定量データとして可視化します。
      </p>
    </header>

    <div class="lp-endock__problems">
      <div class="lp-endock__problem reveal reveal--delay-1">
        <div class="lp-endock__problem-icon" aria-hidden="true">🗣️</div>
        <h4>社員の本音が見えない</h4>
        <p>日常会話や面談では本音が出にくい。経営陣への不満や将来不安は、退職面談で初めて表面化することも。</p>
      </div>
      <div class="lp-endock__problem reveal reveal--delay-2">
        <div class="lp-endock__problem-icon" aria-hidden="true">📉</div>
        <h4>離職の原因がわからない</h4>
        <p>「給与」「人間関係」「成長実感」——離職要因は複合的。感覚的な対策では根本解決に至らない。</p>
      </div>
      <div class="lp-endock__problem reveal reveal--delay-3">
        <div class="lp-endock__problem-icon" aria-hidden="true">🌡️</div>
        <h4>部門ごとの温度差</h4>
        <p>同じ会社でも部門によって「働きやすさ」は大きく異なる。全社一律の施策では効果にムラが出る。</p>
      </div>
      <div class="lp-endock__problem reveal reveal--delay-4">
        <div class="lp-endock__problem-icon" aria-hidden="true">📊</div>
        <h4>施策の効果が測れない</h4>
        <p>研修やイベントを実施しても「やった感」だけで終わっていないか。投資対効果の説明が難しい。</p>
      </div>
    </div>
  </div>
</section>

<!-- ============================================================
     4. ダッシュボードプレビュー（実物 iframe）
     ============================================================ -->
<section class="lp-endock__section" id="dashboard" aria-labelledby="dash-title">
  <div class="lp-endock__container--wide" style="max-width:1280px;margin:0 auto;padding:0 24px;">
    <header class="lp-endock__section-header reveal">
      <span class="lp-endock__eyebrow">LIVE PREVIEW</span>
      <h2 class="lp-endock__h2" id="dash-title">
        言葉ではなく、<em>実物を、ご覧ください。</em>
      </h2>
      <span class="lp-endock__rule"></span>
      <p class="lp-endock__section-desc">
        以下は、endockが納品するインタラクティブダッシュボードの<strong>サンプル</strong>です。<br>
        7つのタブを実際にクリックして、レーダーチャート・トレンド・部門別比較などを体験してください。
      </p>
    </header>

    <div class="lp-endock__dashboard-wrap reveal">
      <div class="lp-endock__dashboard-frame">
        <div class="lp-endock__dashboard-bar" aria-hidden="true">
          <span class="lp-endock__dashboard-dot"></span>
          <span class="lp-endock__dashboard-dot"></span>
          <span class="lp-endock__dashboard-dot"></span>
          <span class="lp-endock__dashboard-url">endock-dashboard / sample-company / 2026年度</span>
        </div>
        <iframe
          class="lp-endock__dashboard-iframe"
          src="<?php echo $dashboard_url; ?>"
          title="endock サンプルダッシュボード"
          loading="lazy"
          referrerpolicy="no-referrer"></iframe>
      </div>
      <p class="lp-endock__dashboard-note">
        ※ 上記は<strong>架空企業のサンプルデータ</strong>です。実装ではお客様のデータでこの通りのダッシュボードが納品されます。
      </p>
    </div>
  </div>
</section>

<!-- ============================================================
     5. 4軸 + 8カテゴリ
     ============================================================ -->
<section class="lp-endock__section lp-endock__section--warm" aria-labelledby="cat-title">
  <div class="lp-endock__container">
    <header class="lp-endock__section-header reveal">
      <span class="lp-endock__eyebrow">DIAGNOSIS STRUCTURE</span>
      <h2 class="lp-endock__h2" id="cat-title">
        4つの軸と <em>8つのカテゴリ</em>で、<br>組織を立体的に診る。
      </h2>
      <span class="lp-endock__rule"></span>
      <p class="lp-endock__section-desc">
        「会社」「上司」「同僚」「仕事」の4つの集計軸 × 8つの診断カテゴリ・60問で、組織の健康状態を多角的に把握します。
      </p>
    </header>

    <div class="lp-endock__axes reveal" aria-label="4つの集計軸">
      <div class="lp-endock__axis">
        <div class="lp-endock__axis-name">会社</div>
        <div class="lp-endock__axis-desc">経営・制度・環境<br>32問</div>
      </div>
      <div class="lp-endock__axis">
        <div class="lp-endock__axis-name">上司</div>
        <div class="lp-endock__axis-desc">マネジメント・関係性<br>9問</div>
      </div>
      <div class="lp-endock__axis">
        <div class="lp-endock__axis-name">同僚</div>
        <div class="lp-endock__axis-desc">志向・チーム力<br>10問</div>
      </div>
      <div class="lp-endock__axis">
        <div class="lp-endock__axis-name">仕事</div>
        <div class="lp-endock__axis-desc">目標・充実度<br>9問</div>
      </div>
    </div>

    <div class="lp-endock__cats reveal">
      <article class="lp-endock__cat">
        <span class="lp-endock__cat-key">A ／ 会社</span>
        <h4>経営（トップマネジメント）</h4>
        <p>経営方針の浸透、経営層への信頼、変革意欲、将来性、現場感覚を測定。</p>
        <div class="lp-endock__cat-meta">9問</div>
      </article>
      <article class="lp-endock__cat">
        <span class="lp-endock__cat-key">B ／ 会社</span>
        <h4>人事制度</h4>
        <p>評価の公正性、待遇・報酬、コンプライアンス、人材育成機会を多面的に測定。</p>
        <div class="lp-endock__cat-meta">14問</div>
      </article>
      <article class="lp-endock__cat">
        <span class="lp-endock__cat-key">C ／ 会社</span>
        <h4>労働環境</h4>
        <p>情報伝達、職場の活気、業務負荷、効率性など、働く環境の質を測定。</p>
        <div class="lp-endock__cat-meta">9問</div>
      </article>
      <article class="lp-endock__cat">
        <span class="lp-endock__cat-key">D ／ 上司</span>
        <h4>リーダーシップ</h4>
        <p>上司の課題把握力、施策実行力、キャリア対話の実践度を測定。</p>
        <div class="lp-endock__cat-meta">3問</div>
      </article>
      <article class="lp-endock__cat">
        <span class="lp-endock__cat-key">E ／ 上司</span>
        <h4>対人関係（上司）</h4>
        <p>フィードバックの質、面談の雰囲気、信頼関係、育成姿勢を測定。</p>
        <div class="lp-endock__cat-meta">6問</div>
      </article>
      <article class="lp-endock__cat">
        <span class="lp-endock__cat-key">F ／ 同僚</span>
        <h4>仕事の志向</h4>
        <p>顧客志向、チャレンジ意欲、責任感など、仕事に対する姿勢を測定。</p>
        <div class="lp-endock__cat-meta">3問</div>
      </article>
      <article class="lp-endock__cat">
        <span class="lp-endock__cat-key">G ／ 同僚</span>
        <h4>組織連帯感</h4>
        <p>チーム内コミュニケーション、相互成長、結束力、部門間連携を測定。</p>
        <div class="lp-endock__cat-meta">7問</div>
      </article>
      <article class="lp-endock__cat">
        <span class="lp-endock__cat-key">H ／ 仕事</span>
        <h4>個人特性（仕事）</h4>
        <p>目標納得度、適材適所の実感、成長実感、モチベーション、定着意向を測定。</p>
        <div class="lp-endock__cat-meta">9問</div>
      </article>
    </div>
  </div>
</section>

<!-- ============================================================
     6. 7タブのダッシュボード解説
     ============================================================ -->
<section class="lp-endock__section" aria-labelledby="tabs-title">
  <div class="lp-endock__container">
    <header class="lp-endock__section-header reveal">
      <span class="lp-endock__eyebrow">DASHBOARD</span>
      <h2 class="lp-endock__h2" id="tabs-title">
        7つのタブで、<em>多角的に分析。</em>
      </h2>
      <span class="lp-endock__rule"></span>
      <p class="lp-endock__section-desc">
        ダッシュボードは7つのタブで構成。経営層・人事・現場、それぞれの視点で組織の状態を読み解けます。
      </p>
    </header>

    <div class="lp-endock__tabs">
      <article class="lp-endock__tab reveal">
        <span class="lp-endock__tab-num">01</span>
        <div class="lp-endock__tab-icon">概</div>
        <h4>概要</h4>
        <p>総合スコア、4軸KPI、ヒートマップ、年度別成長ストーリーを一覧。経営会議の冒頭資料に最適。</p>
      </article>
      <article class="lp-endock__tab reveal">
        <span class="lp-endock__tab-num">02</span>
        <div class="lp-endock__tab-icon">レ</div>
        <h4>レーダー</h4>
        <p>4軸／8カテゴリのレーダーチャート。年度選択で過去データと比較し、組織の「形」を直感的に把握。</p>
      </article>
      <article class="lp-endock__tab reveal">
        <span class="lp-endock__tab-num">03</span>
        <div class="lp-endock__tab-icon">ト</div>
        <h4>トレンド</h4>
        <p>折れ線グラフで5年間の推移を可視化。どの軸が伸びているか、成長率の変化はどうか一目瞭然。</p>
      </article>
      <article class="lp-endock__tab reveal">
        <span class="lp-endock__tab-num">04</span>
        <div class="lp-endock__tab-icon">詳</div>
        <h4>カテゴリ詳細</h4>
        <p>8カテゴリそれぞれのスコアと5年間の変化量を表示。重点的に改善すべき領域を特定。</p>
      </article>
      <article class="lp-endock__tab reveal">
        <span class="lp-endock__tab-num">05</span>
        <div class="lp-endock__tab-icon">部</div>
        <h4>部門別</h4>
        <p>部門 × 4軸のクロス分析。部門ごとの強み・弱みを比較し、個別施策の根拠データに。</p>
      </article>
      <article class="lp-endock__tab reveal">
        <span class="lp-endock__tab-num">06</span>
        <div class="lp-endock__tab-icon">声</div>
        <h4>自由記述</h4>
        <p>従業員の生の声を「満足度が高いコメント」と「改善期待のコメント」に分類して表示。</p>
      </article>
      <article class="lp-endock__tab reveal">
        <span class="lp-endock__tab-num">07</span>
        <div class="lp-endock__tab-icon">提</div>
        <h4>施策提案</h4>
        <p>診断データに基づき、御社に最適化した具体的な組織開発施策を12ヶ月の実施スケジュール案つきで提案。</p>
      </article>
    </div>
  </div>
</section>

<!-- ============================================================
     7. 引用ブロック（ダーク背景）
     ============================================================ -->
<section class="lp-endock__section lp-endock__section--dark" aria-label="えんのしたの哲学">
  <div class="lp-endock__container">
    <div class="lp-endock__pullquote reveal">
      <div class="lp-endock__pullquote-mark" aria-hidden="true">“</div>
      <blockquote class="lp-endock__pullquote-text">
        調査して終わりではない。<br>
        データを「行動」に変える、<br>そこからが私たちの仕事です。
      </blockquote>
      <p class="lp-endock__pullquote-author">— えんのした流・組織開発の哲学</p>
    </div>
  </div>
</section>

<!-- ============================================================
     8. 調査の流れ
     ============================================================ -->
<section class="lp-endock__section" aria-labelledby="flow-title">
  <div class="lp-endock__container">
    <header class="lp-endock__section-header reveal">
      <span class="lp-endock__eyebrow">PROCESS</span>
      <h2 class="lp-endock__h2" id="flow-title">調査の、流れ。</h2>
      <span class="lp-endock__rule"></span>
      <p class="lp-endock__section-desc">
        お申し込みからダッシュボード納品、施策提案まで、<strong>およそ4〜6週間</strong>で完了します。
      </p>
    </header>

    <div class="lp-endock__flow">
      <div class="lp-endock__flow-step reveal">
        <span class="lp-endock__flow-num">1</span>
        <span class="lp-endock__flow-duration">1〜2日</span>
        <h4>事前ヒアリング</h4>
        <p>部署構成・職位体系・調査目的を確認し、カスタマイズ箇所を特定します。</p>
      </div>
      <div class="lp-endock__flow-step reveal reveal--delay-1">
        <span class="lp-endock__flow-num">2</span>
        <span class="lp-endock__flow-duration">3〜5日</span>
        <h4>調査フォーム構築</h4>
        <p>Webアンケートを構築。社員はスマートフォンからも回答可能。完全匿名制で率直な回答を促進。</p>
      </div>
      <div class="lp-endock__flow-step reveal reveal--delay-2">
        <span class="lp-endock__flow-num">3</span>
        <span class="lp-endock__flow-duration">1〜2週間</span>
        <h4>調査実施</h4>
        <p>全従業員にメール等で案内し回答を収集。回答率向上のリマインド文面もご用意します。</p>
      </div>
      <div class="lp-endock__flow-step reveal reveal--delay-3">
        <span class="lp-endock__flow-num">4</span>
        <span class="lp-endock__flow-duration">1〜2週間</span>
        <h4>分析・ダッシュボード作成</h4>
        <p>回収データを集計・換算し、7タブのインタラクティブダッシュボードを生成します。</p>
      </div>
      <div class="lp-endock__flow-step reveal reveal--delay-4">
        <span class="lp-endock__flow-num">5</span>
        <span class="lp-endock__flow-duration">90分</span>
        <h4>報告会・施策提案</h4>
        <p>経営層・人事担当者へ報告会を実施。データに基づく具体的な施策提案書を納品します。</p>
      </div>
    </div>
  </div>
</section>

<!-- ============================================================
     9. 施策メニュー
     ============================================================ -->
<section class="lp-endock__section lp-endock__section--section" aria-labelledby="services-title">
  <div class="lp-endock__container">
    <header class="lp-endock__section-header reveal">
      <span class="lp-endock__eyebrow">FOLLOW-UP SERVICES</span>
      <h2 class="lp-endock__h2" id="services-title">
        診断後の、<em>具体的な施策メニュー。</em>
      </h2>
      <span class="lp-endock__rule"></span>
      <p class="lp-endock__section-desc">
        endockの診断結果に基づき、組織開発の専門家が御社に最適な施策をご提案・実行します。
      </p>
    </header>

    <div class="lp-endock__services">
      <article class="lp-endock__service reveal">
        <div class="lp-endock__service-icon">CMBO</div>
        <h4>CMBO（目標管理制度）の導入・運用支援</h4>
        <p>えんのした独自のCreative Management by Objectives。「やらされ目標」から「自分ごと化された目標」への転換を、対話型プロセスで実現。</p>
        <div class="lp-endock__service-tags">
          <span class="lp-endock__service-tag">H特性改善</span>
          <span class="lp-endock__service-tag">目標管理</span>
        </div>
      </article>

      <article class="lp-endock__service reveal reveal--delay-1">
        <div class="lp-endock__service-icon">L</div>
        <h4>リーダーシップ開発プログラム</h4>
        <p>「課題形成→達成行動→信頼形成」の3軸モデルに基づく管理者行動の変容。座学＋職場実践＋コーチングの6ヶ月間で行動変容を定着。</p>
        <div class="lp-endock__service-tags">
          <span class="lp-endock__service-tag">D/Eスコア改善</span>
          <span class="lp-endock__service-tag">360度FB</span>
        </div>
      </article>

      <article class="lp-endock__service reveal reveal--delay-2">
        <div class="lp-endock__service-icon">LSP</div>
        <h4>レゴ®シリアスプレイ®ワークショップ</h4>
        <p>言語化しにくい組織課題を「手で考える」ことで部門間の相互理解と共通ビジョンを構築。認定ファシリテーターが設計・進行。</p>
        <div class="lp-endock__service-tags">
          <span class="lp-endock__service-tag">G連帯感改善</span>
          <span class="lp-endock__service-tag">LSP認定</span>
        </div>
      </article>

      <article class="lp-endock__service reveal reveal--delay-3">
        <div class="lp-endock__service-icon">1on1</div>
        <h4>キャリア開発支援（1on1の質的向上）</h4>
        <p>国家資格キャリアコンサルタントの知見を活かし、「評価のための面談」から「成長のための対話」への転換を支援。</p>
        <div class="lp-endock__service-tags">
          <span class="lp-endock__service-tag">B人事制度</span>
          <span class="lp-endock__service-tag">1on1</span>
        </div>
      </article>

      <article class="lp-endock__service reveal">
        <div class="lp-endock__service-icon">評</div>
        <h4>評価制度の運用改善コンサルティング</h4>
        <p>制度そのものの再設計ではなく「運用」にフォーカス。評価者訓練、フィードバック面談の標準化、評価結果の透明性向上を支援。</p>
        <div class="lp-endock__service-tags">
          <span class="lp-endock__service-tag">B人事制度</span>
          <span class="lp-endock__service-tag">MBA</span>
        </div>
      </article>

      <article class="lp-endock__service reveal reveal--delay-1">
        <div class="lp-endock__service-icon">管</div>
        <h4>管理職育成プログラム</h4>
        <p>全12回の体系的プログラムで次世代リーダーを育成。基礎的なマネジメントスキルから戦略的思考まで、段階的に習得。</p>
        <div class="lp-endock__service-tags">
          <span class="lp-endock__service-tag">管理職研修</span>
          <span class="lp-endock__service-tag">リーダー育成</span>
        </div>
      </article>

      <article class="lp-endock__service reveal reveal--delay-2">
        <div class="lp-endock__service-icon">研</div>
        <h4>リーダーシップ研修</h4>
        <p>リーダーの本質を理解しチームを動かす力を習得。現場で即実践できるコミュニケーションスキルを体験型で学習。</p>
        <div class="lp-endock__service-tags">
          <span class="lp-endock__service-tag">リーダーシップ</span>
          <span class="lp-endock__service-tag">組織開発</span>
        </div>
      </article>
    </div>
  </div>
</section>

<!-- ============================================================
     10. FAQ
     ============================================================ -->
<section class="lp-endock__section" aria-labelledby="faq-title">
  <div class="lp-endock__container">
    <header class="lp-endock__section-header reveal">
      <span class="lp-endock__eyebrow">FAQ</span>
      <h2 class="lp-endock__h2" id="faq-title">よくあるご質問</h2>
      <span class="lp-endock__rule"></span>
    </header>

    <div class="lp-endock__faq reveal">
      <details class="lp-endock__faq-item">
        <summary class="lp-endock__faq-q">どのくらいの規模の企業が対象ですか？</summary>
        <div class="lp-endock__faq-a">
          30名規模の中小企業から、複数拠点をもつ中堅企業まで対応可能です。500名超の規模については、設計段階から個別にご相談ください。
        </div>
      </details>

      <details class="lp-endock__faq-item">
        <summary class="lp-endock__faq-q">回答にどれくらい時間がかかりますか？</summary>
        <div class="lp-endock__faq-a">
          標準60問版で約20分です。負担を抑えたい場合は40問版（約12分）もご用意しています。スマートフォン対応で、通勤時間などにも回答できます。
        </div>
      </details>

      <details class="lp-endock__faq-item">
        <summary class="lp-endock__faq-q">回答内容が誰に見られるか心配です</summary>
        <div class="lp-endock__faq-a">
          完全匿名制です。個人を特定できる形で経営層・人事に共有されることはありません。集計は属性カテゴリ単位（部門・職位など）でのみ行います。
        </div>
      </details>

      <details class="lp-endock__faq-item">
        <summary class="lp-endock__faq-q">料金はいくらですか？</summary>
        <div class="lp-endock__faq-a">
          導入規模・調査範囲に応じた個別見積となります。おおよその目安は無料相談時にお伝えします。料金表のPDFは対面・オンラインミーティング時にご提示します。
        </div>
      </details>

      <details class="lp-endock__faq-item">
        <summary class="lp-endock__faq-q">他社の従業員満足度調査と何が違うのですか？</summary>
        <div class="lp-endock__faq-a">
          ① 学術的根拠に基づく60問の体系的設問、② 報告書ではなくインタラクティブダッシュボードでの納品、③ 調査結果に基づく具体的な組織開発施策を「えんのした」自身が一気通貫で支援する点が大きな違いです。
        </div>
      </details>

      <details class="lp-endock__faq-item">
        <summary class="lp-endock__faq-q">継続的に毎年実施できますか？</summary>
        <div class="lp-endock__faq-a">
          可能です。むしろ、経年比較ができてこそ「施策の効果」が定量的に検証できます。2年目以降は基本料金の60%でリピート対応します。
        </div>
      </details>

      <details class="lp-endock__faq-item">
        <summary class="lp-endock__faq-q">問い合わせ後にしつこく営業されませんか？</summary>
        <div class="lp-endock__faq-a">
          ご安心ください。営業電話・しつこいご連絡はいたしません。お問い合わせの段階では「組織課題を一緒に整理する場」としてご活用ください。
        </div>
      </details>
    </div>
  </div>
</section>

<!-- ============================================================
     11. 最終CTA
     ============================================================ -->
<section class="lp-endock__final" id="contact" aria-labelledby="cta-title">
  <div class="lp-endock__final-inner">
    <h2 id="cta-title" class="reveal">まず、組織のいまを<br>一緒に整理してみませんか。</h2>
    <p class="reveal reveal--delay-1">
      導入規模・調査範囲に応じて、個別にお見積りいたします。<br>
      30名規模の中小企業から、複数拠点を持つ中堅企業まで対応可能。<br>
      売り込みではなく、御社の組織課題を一緒に整理する場として、お気軽にお使いください。
    </p>
    <div class="lp-endock__final-actions reveal reveal--delay-2">
      <a href="<?php echo $contact_url; ?>" class="lp-endock__btn lp-endock__btn--light">
        無料相談・お問い合わせ <span class="lp-endock__btn-arrow">→</span>
      </a>
      <a href="<?php echo $about_url; ?>" class="lp-endock__btn lp-endock__btn--ghost" style="color:#fff;border-color:rgba(255,255,255,0.6);">
        えんのしたについて
      </a>
    </div>
    <p class="lp-endock__assurance">— 営業電話・しつこいご連絡は、いたしません。</p>
  </div>
</section>

</main>

<!-- ============================================================
     12. フッター
     ============================================================ -->
<footer class="lp-endock__footer" role="contentinfo">
  <div class="lp-endock__footer-inner">
    <div class="lp-endock__footer-brand">
      <img src="<?php echo esc_url($theme_uri); ?>/lp-endock/assets/logo-primary.png" alt="株式会社えんのした">
    </div>
    <div class="lp-endock__footer-info">
      <p class="lp-endock__footer-name">株式会社えんのした ／ 代表取締役 川路 隆志</p>
      <p>〒700-0826　岡山市北区磨屋町10-20　磨屋町ビル8階</p>
      <p>TEL: 086-237-4455 ／ FAX: 086-899-6496</p>
      <p>
        <a href="https://www.ennoshita.co.jp/">www.ennoshita.co.jp</a>
        ／
        <a href="mailto:kawaji@ennoshita.co.jp">kawaji@ennoshita.co.jp</a>
      </p>
    </div>
  </div>
  <p class="lp-endock__copy">© <?php echo esc_html(date_i18n('Y')); ?> ENNOSHITA Inc. All rights reserved.</p>
</footer>

<!-- ============================================================
     スクロール演出（IntersectionObserver）
     ============================================================ -->
<script>
(function () {
  if (!('IntersectionObserver' in window)) {
    document.querySelectorAll('.lp-endock .reveal').forEach(function (el) {
      el.classList.add('is-visible');
    });
    return;
  }
  var io = new IntersectionObserver(function (entries) {
    entries.forEach(function (entry) {
      if (entry.isIntersecting) {
        entry.target.classList.add('is-visible');
        io.unobserve(entry.target);
      }
    });
  }, { threshold: 0.12, rootMargin: '0px 0px -40px 0px' });
  document.querySelectorAll('.lp-endock .reveal').forEach(function (el) {
    io.observe(el);
  });
})();
</script>

<?php wp_footer(); ?>
</body>
</html>
