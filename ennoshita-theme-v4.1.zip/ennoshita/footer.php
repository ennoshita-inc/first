</main><!-- /#main-content -->

<footer class="site-footer" role="contentinfo">
  <div class="container">
    <div class="footer__inner">

      <div class="footer__brand">
        <?php ennoshita_the_logo('footer__logo'); ?>
        <p class="footer__description">
          人・職場・組織を支えるコンサルティング会社。<br>
          多様な学びの場を提供し、リーダーの心技体を育みます。
        </p>
        <?php
        $sns_links = [
            'x'         => ['label' => 'X',         'icon' => '<svg viewBox="0 0 24 24" width="18" height="18" fill="currentColor"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg>'],
            'facebook'  => ['label' => 'Facebook',  'icon' => '<svg viewBox="0 0 24 24" width="18" height="18" fill="currentColor"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg>'],
            'instagram' => ['label' => 'Instagram', 'icon' => '<svg viewBox="0 0 24 24" width="18" height="18" fill="currentColor"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zM12 0C8.741 0 8.333.014 7.053.072 2.695.272.273 2.69.073 7.052.014 8.333 0 8.741 0 12c0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98C8.333 23.986 8.741 24 12 24c3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98C15.668.014 15.259 0 12 0zm0 5.838a6.162 6.162 0 100 12.324 6.162 6.162 0 000-12.324zM12 16a4 4 0 110-8 4 4 0 010 8zm6.406-11.845a1.44 1.44 0 100 2.881 1.44 1.44 0 000-2.881z"/></svg>'],
            'linkedin'  => ['label' => 'LinkedIn',  'icon' => '<svg viewBox="0 0 24 24" width="18" height="18" fill="currentColor"><path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433a2.062 2.062 0 01-2.063-2.065 2.064 2.064 0 112.063 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/></svg>'],
        ];
        $has_sns = false;
        foreach ($sns_links as $key => $data) {
            if (get_theme_mod("ennoshita_sns_{$key}")) { $has_sns = true; break; }
        }
        if ($has_sns) : ?>
          <div class="footer__sns">
            <?php foreach ($sns_links as $key => $data) :
              $url = get_theme_mod("ennoshita_sns_{$key}");
              if ($url) : ?>
                <a href="<?php echo esc_url($url); ?>" class="footer__sns-link" target="_blank" rel="noopener noreferrer" aria-label="<?php echo esc_attr($data['label']); ?>">
                  <?php echo $data['icon']; ?>
                </a>
              <?php endif;
            endforeach; ?>
          </div>
        <?php endif; ?>
      </div>

      <div class="footer__column">
        <h3 class="footer__heading">サービス</h3>
        <?php if (has_nav_menu('footer-1')) : ?>
          <?php wp_nav_menu([
            'theme_location' => 'footer-1',
            'container'      => false,
            'menu_class'     => 'footer__nav',
            'depth'          => 1,
          ]); ?>
        <?php else : ?>
          <ul class="footer__nav">
            <li><a href="<?php echo esc_url(home_url('/service/training/')); ?>">人材育成サービス</a></li>
            <li><a href="<?php echo esc_url(home_url('/service/hr-system/')); ?>">人事制度構築支援</a></li>
            <li><a href="<?php echo esc_url(home_url('/service/organization/')); ?>">組織開発支援</a></li>
            <li><a href="<?php echo esc_url(home_url('/#process')); ?>">導入の流れ</a></li>
          </ul>
        <?php endif; ?>
      </div>

      <div class="footer__column">
        <h3 class="footer__heading">企業情報</h3>
        <?php if (has_nav_menu('footer-2')) : ?>
          <?php wp_nav_menu([
            'theme_location' => 'footer-2',
            'container'      => false,
            'menu_class'     => 'footer__nav',
            'depth'          => 1,
          ]); ?>
        <?php else : ?>
          <ul class="footer__nav">
            <li><a href="<?php echo esc_url(home_url('/about/')); ?>">会社概要</a></li>
            <li><a href="<?php echo esc_url(ennoshita_get_blog_url()); ?>">コラム</a></li>
            <li><a href="<?php echo esc_url(home_url('/contact/')); ?>">お問い合わせ</a></li>
            <li><a href="<?php echo esc_url(home_url('/sitemap/')); ?>">サイトマップ</a></li>
          </ul>
        <?php endif; ?>
      </div>

      <div class="footer__column">
        <h3 class="footer__heading">アクセス</h3>
        <dl class="footer__info">
          <dt>所在地</dt>
          <dd><?php echo nl2br(esc_html(get_theme_mod('ennoshita_address', '岡山県岡山市 磨屋町ビル8階'))); ?></dd>
          <?php
          $phone = get_theme_mod('ennoshita_phone');
          if ($phone) : ?>
            <dt>電話番号</dt>
            <dd><a href="tel:<?php echo esc_attr(preg_replace('/[^0-9+]/', '', $phone)); ?>"><?php echo esc_html($phone); ?></a></dd>
          <?php endif; ?>
          <dt>お問い合わせ</dt>
          <dd><a href="<?php echo esc_url(home_url('/contact/')); ?>">お問い合わせフォーム</a></dd>
        </dl>
      </div>

    </div><!-- /.footer__inner -->

    <div class="footer__bottom">
      <p>&copy; <?php echo esc_html(wp_date('Y')); ?> 株式会社えんのした. All rights reserved.</p>
      <nav class="footer__bottom-nav" aria-label="フッター補足ナビゲーション">
        <a href="<?php echo esc_url(home_url('/privacy/')); ?>">プライバシーポリシー</a>
        <a href="<?php echo esc_url(home_url('/sitemap/')); ?>">サイトマップ</a>
      </nav>
    </div>
  </div>
</footer>

<!-- Cookie同意バナー -->
<div class="cookie-consent" id="cookie-consent" role="dialog" aria-label="Cookie使用の同意">
  <div class="cookie-consent__inner">
    <p class="cookie-consent__text">
      当サイトでは、サービス向上のためCookieを使用しています。
      詳しくは<a href="<?php echo esc_url(home_url('/privacy/')); ?>">プライバシーポリシー</a>をご覧ください。
    </p>
    <div class="cookie-consent__buttons">
      <button class="cookie-consent__accept" id="cookie-accept">同意する</button>
    </div>
  </div>
</div>

<button class="back-to-top" aria-label="ページトップへ戻る">
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
    <path d="M18 15l-6-6-6 6"/>
  </svg>
</button>

<?php wp_footer(); ?>
</body>
</html>
