<?php
/**
 * Template Name: endock LP
 *
 * 組織活力調査 endock のランディングページ。
 *
 * 既存テーマと完全に統一感を保つため：
 * - get_header() / get_footer() で既存サイトのヘッダー・フッター・グローバルナビをそのまま継承
 * - 既存 style.css の .page-header / .section / .v11-* / .trust / .process / .btn 等のコンポーネントをフル活用
 * - LP固有の追加スタイルは lp-endock/lp-endock.css に最小限（.endock- プレフィックス）
 * - 既存 style.css には一切手を加えない
 */

if (!defined('ABSPATH')) { exit; }

$theme_uri      = get_template_directory_uri();
$contact_url    = esc_url(home_url('/contact/'));
$dashboard_url  = esc_url($theme_uri . '/lp-endock/dashboard-sample.html');

// LP固有CSSのみ追加読み込み（既存テーマには影響しない）
add_action('wp_enqueue_scripts', function () use ($theme_uri) {
  wp_enqueue_style(
    'endock-lp',
    $theme_uri . '/lp-endock/lp-endock.css',
    [],
    '2.0.0'
  );
}, 20);

get_header();
?>

<main id="main-content">

<!-- 1. ページヘッダー（既存 .page-header のダーク背景） -->
<div class="page-header">
  <div class="container">
    <p class="page-header__label">Organizational Vitality Survey</p>
    <h1 class="page-header__title">
      組織活力調査 <span class="endock-brand">endock</span>
    </h1>
    <p class="page-header__subtitle">
      数字で見えにくい「組織の活力」を、データで可視化する組織健診。
    </p>
  </div>
</div>

<!-- 1.5. ヒーロー直下：3つの価値キーワード + スクロール誘導 -->
<div class="endock-keystrip">
  <div class="container">
    <ul class="endock-keystrip__list reveal" aria-label="endock の3つの価値">
      <li class="endock-keystrip__item">
        <span class="endock-keystrip__num" aria-hidden="true">01</span>
        <span class="endock-keystrip__word">可視化</span>
        <span class="endock-keystrip__sub">Visualize</span>
        <span class="endock-keystrip__desc">8カテゴリ60問で<br>組織を立体的に診る</span>
      </li>
      <li class="endock-keystrip__item">
        <span class="endock-keystrip__num" aria-hidden="true">02</span>
        <span class="endock-keystrip__word">対話</span>
        <span class="endock-keystrip__sub">Dialogue</span>
        <span class="endock-keystrip__desc">経営層・人事・現場の<br>共通言語を作る</span>
      </li>
      <li class="endock-keystrip__item">
        <span class="endock-keystrip__num" aria-hidden="true">03</span>
        <span class="endock-keystrip__word">行動変容</span>
        <span class="endock-keystrip__sub">Action</span>
        <span class="endock-keystrip__desc">えんのしたが伴走し<br>具体的な施策を実行</span>
      </li>
    </ul>
    <div class="endock-keystrip__cta reveal reveal--delay-1">
      <a href="#dashboard-section" class="endock-keystrip__scroll">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="6 9 12 15 18 9"/></svg>
        <span>実物のダッシュボードを見る</span>
      </a>
    </div>
  </div>
</div>

<!-- 2. パンくず -->
<?php if (function_exists('ennoshita_breadcrumb')) { ennoshita_breadcrumb(); } ?>

<!-- 3. 統計バー（既存 .trust__grid 流儀） -->
<section class="section section--dark" aria-labelledby="endock-stats-title">
  <div class="container">
    <div class="section-header reveal">
      <p class="section-header__label">At a Glance</p>
      <h2 class="section-header__title" id="endock-stats-title">endock を、数字で。</h2>
      <span class="section-header__line" aria-hidden="true"></span>
    </div>
    <div class="trust__grid reveal">
      <div class="trust__item">
        <p class="trust__number" data-count="60">0<small>問</small></p>
        <p class="trust__label">標準設問数</p>
      </div>
      <div class="trust__item">
        <p class="trust__number" data-count="8">0<small>カテゴリ</small></p>
        <p class="trust__label">診断カテゴリ</p>
      </div>
      <div class="trust__item">
        <p class="trust__number" data-count="4">0<small>軸</small></p>
        <p class="trust__label">集計軸</p>
      </div>
      <div class="trust__item">
        <p class="trust__number" data-count="7">0<small>タブ</small></p>
        <p class="trust__label">ダッシュボード</p>
      </div>
    </div>
    <p class="endock-scale-note">
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
      <span>30 名規模の中小企業から、複数拠点をもつ中堅企業まで対応可能</span>
    </p>
  </div>
</section>

<!-- 4. endock とは（既存 .v11-overview 流儀） -->
<section class="section" style="background:linear-gradient(180deg, var(--color-bg-warm), #fff)" aria-labelledby="endock-overview-title">
  <div class="container">
    <div class="section-header reveal">
      <p class="section-header__label">Overview</p>
      <h2 class="section-header__title" id="endock-overview-title">endock とは</h2>
      <span class="section-header__line" aria-hidden="true"></span>
    </div>
    <div class="v11-overview reveal">
      <div>
        <div class="v11-overview-lead">「やった感」で終わる組織調査ではなく、結果を「行動」に変える。</div>
        <p class="v11-overview-text">endock は、組織の状態を 8 つのカテゴリ × 4 つの集計軸 × 60 問で多角的に定量化する、えんのしたの組織健診ツールです。単なるアンケートではなく、調査結果をインタラクティブなダッシュボードとして可視化し、えんのしたが組織開発の施策提案・実行支援までを一気通貫で伴走します。</p>
      </div>
      <div class="v11-overview-features">
        <div class="v11-overview-feat">
          <div class="v11-overview-feat-icon" aria-hidden="true">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2L2 7l10 5 10-5-10-5z"/><path d="M2 17l10 5 10-5"/><path d="M2 12l10 5 10-5"/></svg>
          </div>
          <span class="v11-overview-feat-text">学術的根拠の設問</span>
        </div>
        <div class="v11-overview-feat">
          <div class="v11-overview-feat-icon" aria-hidden="true">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/></svg>
          </div>
          <span class="v11-overview-feat-text">インタラクティブ可視化</span>
        </div>
        <div class="v11-overview-feat">
          <div class="v11-overview-feat-icon" aria-hidden="true">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="23 6 13.5 15.5 8.5 10.5 1 18"/><polyline points="17 6 23 6 23 12"/></svg>
          </div>
          <span class="v11-overview-feat-text">経年比較で変化を追跡</span>
        </div>
        <div class="v11-overview-feat">
          <div class="v11-overview-feat-icon" aria-hidden="true">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
          </div>
          <span class="v11-overview-feat-text">具体的な施策提案</span>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- 5. こんな課題ありませんか（既存 .v11-targets 流儀） -->
<section class="section section--gray" aria-labelledby="endock-targets-title">
  <div class="container">
    <div class="section-header reveal">
      <p class="section-header__label">For You</p>
      <h2 class="section-header__title" id="endock-targets-title">こんな課題、感じていませんか</h2>
      <span class="section-header__line" aria-hidden="true"></span>
    </div>
    <div class="v11-targets reveal">
      <div class="v11-target">
        <div class="v11-target-icon" aria-hidden="true">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"/></svg>
        </div>
        <span>社員の本音が見えず、退職面談で初めて課題を知る</span>
      </div>
      <div class="v11-target">
        <div class="v11-target-icon" aria-hidden="true">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"/></svg>
        </div>
        <span>離職の本当の原因がわからない</span>
      </div>
      <div class="v11-target">
        <div class="v11-target-icon" aria-hidden="true">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"/></svg>
        </div>
        <span>部門ごとの温度差を、感覚でしか把握できない</span>
      </div>
      <div class="v11-target">
        <div class="v11-target-icon" aria-hidden="true">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"/></svg>
        </div>
        <span>研修・施策の効果が「やった感」で終わってしまう</span>
      </div>
      <div class="v11-target">
        <div class="v11-target-icon" aria-hidden="true">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"/></svg>
        </div>
        <span>経営層に組織状態をデータで説明する必要がある</span>
      </div>
      <div class="v11-target">
        <div class="v11-target-icon" aria-hidden="true">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"/></svg>
        </div>
        <span>組織開発の施策を、客観的な根拠を持って打ち出したい</span>
      </div>
    </div>
  </div>
</section>

<!-- 6. 4軸 × 8カテゴリ図解（独自セクション・SVG同心円） -->
<section class="section" aria-labelledby="endock-orbit-title">
  <div class="container">
    <div class="section-header reveal">
      <p class="section-header__label">Diagnosis Structure</p>
      <h2 class="section-header__title" id="endock-orbit-title">4 つの軸と 8 つのカテゴリで、立体的に診る</h2>
      <span class="section-header__line" aria-hidden="true"></span>
      <p class="section-header__description">
        「会社」「上司」「同僚」「仕事」の 4 つの集計軸 × 8 つの診断カテゴリ・60 問で、組織の健康状態を多角的に把握します。
      </p>
    </div>

    <div class="endock-orbit reveal" aria-label="4軸×8カテゴリの構造図">
      <svg viewBox="0 0 640 640" class="endock-orbit__svg" role="img" aria-labelledby="orbit-title-svg">
        <title id="orbit-title-svg">組織の活力を、4軸（会社・上司・同僚・仕事）×8カテゴリで診る構造図</title>
        <defs>
          <radialGradient id="orbit-center-grad" cx="50%" cy="50%" r="50%">
            <stop offset="0%"  stop-color="#a03038"/>
            <stop offset="100%" stop-color="#641a1f"/>
          </radialGradient>
          <filter id="orbit-glow" x="-50%" y="-50%" width="200%" height="200%">
            <feGaussianBlur stdDeviation="6" result="blur"/>
            <feMerge><feMergeNode in="blur"/><feMergeNode in="SourceGraphic"/></feMerge>
          </filter>
        </defs>

        <!-- 同心円（点線） -->
        <circle cx="320" cy="320" r="270" fill="none" stroke="var(--color-border)" stroke-width="1" stroke-dasharray="2 6"/>
        <circle cx="320" cy="320" r="190" fill="none" stroke="var(--color-border)" stroke-width="1" stroke-dasharray="2 6"/>

        <!-- 4軸の方向線（中心→4軸） -->
        <line x1="320" y1="240" x2="320" y2="120" stroke="var(--color-primary-200)" stroke-width="1.5"/>
        <line x1="320" y1="400" x2="320" y2="520" stroke="var(--color-primary-200)" stroke-width="1.5"/>
        <line x1="240" y1="320" x2="120" y2="320" stroke="var(--color-primary-200)" stroke-width="1.5"/>
        <line x1="400" y1="320" x2="520" y2="320" stroke="var(--color-primary-200)" stroke-width="1.5"/>

        <!-- 4軸→外周カテゴリの細線（点線） -->
        <line x1="320" y1="120" x2="220" y2="50" stroke="var(--color-border)" stroke-width="1" stroke-dasharray="2 4"/>
        <line x1="320" y1="120" x2="320" y2="50" stroke="var(--color-border)" stroke-width="1" stroke-dasharray="2 4"/>
        <line x1="320" y1="120" x2="420" y2="50" stroke="var(--color-border)" stroke-width="1" stroke-dasharray="2 4"/>
        <line x1="520" y1="320" x2="600" y2="270" stroke="var(--color-border)" stroke-width="1" stroke-dasharray="2 4"/>
        <line x1="520" y1="320" x2="600" y2="370" stroke="var(--color-border)" stroke-width="1" stroke-dasharray="2 4"/>
        <line x1="320" y1="520" x2="240" y2="595" stroke="var(--color-border)" stroke-width="1" stroke-dasharray="2 4"/>
        <line x1="320" y1="520" x2="400" y2="595" stroke="var(--color-border)" stroke-width="1" stroke-dasharray="2 4"/>
        <line x1="120" y1="320" x2="40"  y2="320" stroke="var(--color-border)" stroke-width="1" stroke-dasharray="2 4"/>

        <!-- 中央：組織 -->
        <circle cx="320" cy="320" r="78" fill="url(#orbit-center-grad)" filter="url(#orbit-glow)"/>
        <circle cx="320" cy="320" r="78" fill="none" stroke="rgba(255,255,255,0.2)" stroke-width="1"/>
        <text x="320" y="313" text-anchor="middle" fill="#fff" font-family="'Noto Serif JP',serif" font-size="20" font-weight="700">組織の</text>
        <text x="320" y="343" text-anchor="middle" fill="#fff" font-family="'Noto Serif JP',serif" font-size="20" font-weight="700">活力</text>

        <!-- 4軸ラベル（円） -->
        <g class="endock-orbit__axis">
          <circle cx="320" cy="120" r="48" fill="#fff" stroke="var(--color-primary)" stroke-width="2.5"/>
          <text x="320" y="115" text-anchor="middle" fill="var(--color-primary)" font-family="'Noto Serif JP',serif" font-size="18" font-weight="700">会社</text>
          <text x="320" y="135" text-anchor="middle" fill="var(--color-accent)" font-family="'Inter',sans-serif" font-size="10" font-weight="600" letter-spacing="0.08em">32 ITEMS</text>
        </g>
        <g class="endock-orbit__axis">
          <circle cx="520" cy="320" r="48" fill="#fff" stroke="var(--color-primary)" stroke-width="2.5"/>
          <text x="520" y="315" text-anchor="middle" fill="var(--color-primary)" font-family="'Noto Serif JP',serif" font-size="18" font-weight="700">上司</text>
          <text x="520" y="335" text-anchor="middle" fill="var(--color-accent)" font-family="'Inter',sans-serif" font-size="10" font-weight="600" letter-spacing="0.08em">9 ITEMS</text>
        </g>
        <g class="endock-orbit__axis">
          <circle cx="320" cy="520" r="48" fill="#fff" stroke="var(--color-primary)" stroke-width="2.5"/>
          <text x="320" y="515" text-anchor="middle" fill="var(--color-primary)" font-family="'Noto Serif JP',serif" font-size="18" font-weight="700">同僚</text>
          <text x="320" y="535" text-anchor="middle" fill="var(--color-accent)" font-family="'Inter',sans-serif" font-size="10" font-weight="600" letter-spacing="0.08em">10 ITEMS</text>
        </g>
        <g class="endock-orbit__axis">
          <circle cx="120" cy="320" r="48" fill="#fff" stroke="var(--color-primary)" stroke-width="2.5"/>
          <text x="120" y="315" text-anchor="middle" fill="var(--color-primary)" font-family="'Noto Serif JP',serif" font-size="18" font-weight="700">仕事</text>
          <text x="120" y="335" text-anchor="middle" fill="var(--color-accent)" font-family="'Inter',sans-serif" font-size="10" font-weight="600" letter-spacing="0.08em">9 ITEMS</text>
        </g>

        <!-- 8カテゴリラベル（外周ピル） -->
        <g font-family="'Noto Sans JP',sans-serif" font-size="11.5" font-weight="600">
          <!-- 上：会社（A,B,C） -->
          <g class="endock-orbit__pill">
            <rect x="170" y="32" width="100" height="30" rx="15" fill="#fff" stroke="var(--color-primary-200)" stroke-width="1.5"/>
            <text x="220" y="51" text-anchor="middle" fill="var(--color-primary)">A. 経営</text>
          </g>
          <g class="endock-orbit__pill">
            <rect x="270" y="32" width="100" height="30" rx="15" fill="#fff" stroke="var(--color-primary-200)" stroke-width="1.5"/>
            <text x="320" y="51" text-anchor="middle" fill="var(--color-primary)">B. 人事制度</text>
          </g>
          <g class="endock-orbit__pill">
            <rect x="370" y="32" width="100" height="30" rx="15" fill="#fff" stroke="var(--color-primary-200)" stroke-width="1.5"/>
            <text x="420" y="51" text-anchor="middle" fill="var(--color-primary)">C. 労働環境</text>
          </g>
          <!-- 右：上司（D,E） -->
          <g class="endock-orbit__pill">
            <rect x="540" y="252" width="98" height="30" rx="15" fill="#fff" stroke="var(--color-primary-200)" stroke-width="1.5"/>
            <text x="589" y="271" text-anchor="middle" fill="var(--color-primary)">D. リーダー</text>
          </g>
          <g class="endock-orbit__pill">
            <rect x="540" y="356" width="98" height="30" rx="15" fill="#fff" stroke="var(--color-primary-200)" stroke-width="1.5"/>
            <text x="589" y="375" text-anchor="middle" fill="var(--color-primary)">E. 対人関係</text>
          </g>
          <!-- 下：同僚（F,G） -->
          <g class="endock-orbit__pill">
            <rect x="200" y="580" width="100" height="30" rx="15" fill="#fff" stroke="var(--color-primary-200)" stroke-width="1.5"/>
            <text x="250" y="599" text-anchor="middle" fill="var(--color-primary)">F. 仕事の志向</text>
          </g>
          <g class="endock-orbit__pill">
            <rect x="340" y="580" width="100" height="30" rx="15" fill="#fff" stroke="var(--color-primary-200)" stroke-width="1.5"/>
            <text x="390" y="599" text-anchor="middle" fill="var(--color-primary)">G. 組織連帯</text>
          </g>
          <!-- 左：仕事（H） -->
          <g class="endock-orbit__pill">
            <rect x="2" y="305" width="98" height="30" rx="15" fill="#fff" stroke="var(--color-primary-200)" stroke-width="1.5"/>
            <text x="51" y="324" text-anchor="middle" fill="var(--color-primary)">H. 個人特性</text>
          </g>
        </g>
      </svg>

      <ul class="endock-orbit__legend">
        <li><span class="endock-orbit__key">A</span><b>経営（トップマネジメント）</b><i>9問</i><em>経営方針の浸透・経営層への信頼・変革意欲</em></li>
        <li><span class="endock-orbit__key">B</span><b>人事制度</b><i>14問</i><em>評価の公正性・待遇・コンプライアンス・育成機会</em></li>
        <li><span class="endock-orbit__key">C</span><b>労働環境</b><i>9問</i><em>情報伝達・職場の活気・業務負荷・効率性</em></li>
        <li><span class="endock-orbit__key">D</span><b>リーダーシップ</b><i>3問</i><em>上司の課題把握・施策実行・キャリア対話</em></li>
        <li><span class="endock-orbit__key">E</span><b>対人関係（上司）</b><i>6問</i><em>FBの質・面談・信頼関係・育成姿勢</em></li>
        <li><span class="endock-orbit__key">F</span><b>仕事の志向</b><i>3問</i><em>顧客志向・チャレンジ意欲・責任感</em></li>
        <li><span class="endock-orbit__key">G</span><b>組織連帯感</b><i>7問</i><em>チーム内コミュ・相互成長・部門間連携</em></li>
        <li><span class="endock-orbit__key">H</span><b>個人特性（仕事）</b><i>9問</i><em>目標納得度・成長実感・モチベーション</em></li>
      </ul>
    </div>
  </div>
</section>

<!-- 7. ★ ダッシュボード実物プレビュー（既存 .section--dark + 独自フレーム） -->
<section class="section section--dark" id="dashboard-section" aria-labelledby="endock-dashboard-title">
  <div class="container">
    <div class="section-header reveal">
      <p class="section-header__label">Live Preview</p>
      <h2 class="section-header__title" id="endock-dashboard-title">実物のダッシュボードを、ご覧ください</h2>
      <span class="section-header__line" aria-hidden="true"></span>
      <p class="section-header__description">
        以下は、endock が納品するインタラクティブダッシュボードの<strong>サンプル</strong>です。<br>
        7 つのタブを実際にクリックして、レーダーチャート・トレンド・部門別比較などをその場で体験してください。
      </p>
    </div>

    <div class="endock-dashboard-stage reveal">
      <div class="endock-dashboard__badge" aria-hidden="true">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="9 11 12 14 22 4"/><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"/></svg>
        <span>クリックして 7 つのタブを切り替えてみてください</span>
      </div>
      <div class="endock-dashboard">
        <div class="endock-dashboard__bar" aria-hidden="true">
          <span class="endock-dashboard__dot" style="background:#ff5f57"></span>
          <span class="endock-dashboard__dot" style="background:#febc2e"></span>
          <span class="endock-dashboard__dot" style="background:#28c840"></span>
          <span class="endock-dashboard__url">endock-dashboard / sample-company / 2026年度</span>
        </div>
        <iframe class="endock-dashboard__iframe" src="<?php echo $dashboard_url; ?>" title="endock サンプルダッシュボード" loading="lazy"></iframe>
      </div>
      <p class="endock-dashboard__note">
        ※ 上記は架空企業のサンプルデータです。実装ではお客様のデータでこの通りのダッシュボードが納品されます。
        <a href="<?php echo $dashboard_url; ?>" target="_blank" rel="noopener" class="endock-dashboard__open">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg>
          別タブで全画面表示
        </a>
      </p>
    </div>
  </div>
</section>

<!-- 8. 7タブのダッシュボード解説（既存 .v11-programs 流儀でアクセントバー付きカード） -->
<section class="section" aria-labelledby="endock-tabs-title">
  <div class="container">
    <div class="section-header reveal">
      <p class="section-header__label">Dashboard</p>
      <h2 class="section-header__title" id="endock-tabs-title">7 つのタブで、多角的に分析</h2>
      <span class="section-header__line" aria-hidden="true"></span>
      <p class="section-header__description">
        ダッシュボードは 7 つのタブで構成。経営層・人事・現場、それぞれの視点で組織の状態を読み解けます。
      </p>
    </div>
    <div class="v11-programs reveal">
      <!-- Tab 01: 概要 ─ KPIタイル -->
      <div class="v11-prog endock-tab">
        <div class="v11-prog-accent" aria-hidden="true"></div>
        <div class="v11-prog-body">
          <div class="endock-tab__chart" aria-hidden="true">
            <svg viewBox="0 0 120 60" width="100%" height="100%">
              <rect x="4"  y="6"  width="34" height="22" rx="3" fill="var(--color-primary-50)"/>
              <rect x="42" y="6"  width="34" height="22" rx="3" fill="var(--color-accent-50)"/>
              <rect x="80" y="6"  width="36" height="22" rx="3" fill="var(--color-primary-100)"/>
              <rect x="4"  y="32" width="112" height="6" rx="2" fill="var(--color-primary-200)"/>
              <rect x="4"  y="32" width="74"  height="6" rx="2" fill="var(--color-primary)"/>
              <rect x="4"  y="44" width="112" height="6" rx="2" fill="var(--color-border)"/>
              <rect x="4"  y="44" width="48"  height="6" rx="2" fill="var(--color-accent)"/>
            </svg>
          </div>
          <div class="v11-prog-header">
            <h3 class="v11-prog-title">概要</h3>
            <span class="v11-prog-num" aria-hidden="true">01</span>
          </div>
          <p class="v11-prog-desc">総合スコア、4軸KPI、ヒートマップ、年度別成長ストーリーを一覧。経営会議の冒頭資料に最適。</p>
        </div>
      </div>

      <!-- Tab 02: レーダー -->
      <div class="v11-prog endock-tab">
        <div class="v11-prog-accent" aria-hidden="true"></div>
        <div class="v11-prog-body">
          <div class="endock-tab__chart" aria-hidden="true">
            <svg viewBox="0 0 120 60" width="100%" height="100%">
              <g transform="translate(60,30)">
                <polygon points="0,-22 19,-7 12,18 -12,18 -19,-7" fill="none" stroke="var(--color-border)" stroke-width="1"/>
                <polygon points="0,-14 12,-4 8,12 -8,12 -12,-4"   fill="none" stroke="var(--color-border)" stroke-width="1"/>
                <polygon points="0,-18 16,-3 10,16 -11,16 -17,-2" fill="rgba(133,34,40,0.15)" stroke="var(--color-primary)" stroke-width="1.5"/>
                <circle cx="0"  cy="-18" r="2" fill="var(--color-primary)"/>
                <circle cx="16" cy="-3"  r="2" fill="var(--color-primary)"/>
                <circle cx="10" cy="16"  r="2" fill="var(--color-primary)"/>
                <circle cx="-11" cy="16" r="2" fill="var(--color-primary)"/>
                <circle cx="-17" cy="-2" r="2" fill="var(--color-primary)"/>
              </g>
            </svg>
          </div>
          <div class="v11-prog-header">
            <h3 class="v11-prog-title">レーダー</h3>
            <span class="v11-prog-num" aria-hidden="true">02</span>
          </div>
          <p class="v11-prog-desc">4軸／8カテゴリのレーダーチャート。年度選択で過去データと比較し、組織の「形」を直感的に把握。</p>
        </div>
      </div>

      <!-- Tab 03: トレンド -->
      <div class="v11-prog endock-tab">
        <div class="v11-prog-accent" aria-hidden="true"></div>
        <div class="v11-prog-body">
          <div class="endock-tab__chart" aria-hidden="true">
            <svg viewBox="0 0 120 60" width="100%" height="100%">
              <line x1="4" y1="50" x2="116" y2="50" stroke="var(--color-border)" stroke-width="1"/>
              <line x1="4" y1="32" x2="116" y2="32" stroke="var(--color-border)" stroke-width="0.5" stroke-dasharray="2 3"/>
              <line x1="4" y1="14" x2="116" y2="14" stroke="var(--color-border)" stroke-width="0.5" stroke-dasharray="2 3"/>
              <polyline points="8,42 30,36 52,30 74,22 96,16 114,8" fill="none" stroke="var(--color-primary)" stroke-width="2"/>
              <polyline points="8,46 30,42 52,40 74,36 96,30 114,24" fill="none" stroke="var(--color-accent)" stroke-width="1.5" stroke-dasharray="3 2"/>
              <circle cx="8" cy="42" r="2.5" fill="var(--color-primary)"/>
              <circle cx="52" cy="30" r="2.5" fill="var(--color-primary)"/>
              <circle cx="114" cy="8" r="2.5" fill="var(--color-primary)"/>
            </svg>
          </div>
          <div class="v11-prog-header">
            <h3 class="v11-prog-title">トレンド</h3>
            <span class="v11-prog-num" aria-hidden="true">03</span>
          </div>
          <p class="v11-prog-desc">折れ線グラフで5年間の推移を可視化。どの軸が伸びているか、成長率の変化はどうか一目瞭然。</p>
        </div>
      </div>

      <!-- Tab 04: カテゴリ詳細 -->
      <div class="v11-prog endock-tab">
        <div class="v11-prog-accent" aria-hidden="true"></div>
        <div class="v11-prog-body">
          <div class="endock-tab__chart" aria-hidden="true">
            <svg viewBox="0 0 120 60" width="100%" height="100%">
              <rect x="4"  y="6"  width="112" height="6" rx="2" fill="var(--color-border)"/>
              <rect x="4"  y="6"  width="92"  height="6" rx="2" fill="var(--color-primary)"/>
              <rect x="4"  y="18" width="112" height="6" rx="2" fill="var(--color-border)"/>
              <rect x="4"  y="18" width="64"  height="6" rx="2" fill="var(--color-primary)"/>
              <rect x="4"  y="30" width="112" height="6" rx="2" fill="var(--color-border)"/>
              <rect x="4"  y="30" width="78"  height="6" rx="2" fill="var(--color-accent)"/>
              <rect x="4"  y="42" width="112" height="6" rx="2" fill="var(--color-border)"/>
              <rect x="4"  y="42" width="40"  height="6" rx="2" fill="var(--color-primary)"/>
            </svg>
          </div>
          <div class="v11-prog-header">
            <h3 class="v11-prog-title">カテゴリ詳細</h3>
            <span class="v11-prog-num" aria-hidden="true">04</span>
          </div>
          <p class="v11-prog-desc">8カテゴリそれぞれのスコアと5年間の変化量を表示。重点的に改善すべき領域を特定。</p>
        </div>
      </div>

      <!-- Tab 05: 部門別（ヒートマップ） -->
      <div class="v11-prog endock-tab">
        <div class="v11-prog-accent" aria-hidden="true"></div>
        <div class="v11-prog-body">
          <div class="endock-tab__chart" aria-hidden="true">
            <svg viewBox="0 0 120 60" width="100%" height="100%">
              <g>
                <rect x="4"   y="6"  width="22" height="14" rx="2" fill="rgba(133,34,40,0.85)"/>
                <rect x="28"  y="6"  width="22" height="14" rx="2" fill="rgba(133,34,40,0.55)"/>
                <rect x="52"  y="6"  width="22" height="14" rx="2" fill="rgba(133,34,40,0.30)"/>
                <rect x="76"  y="6"  width="22" height="14" rx="2" fill="rgba(196,154,42,0.65)"/>
                <rect x="100" y="6"  width="16" height="14" rx="2" fill="rgba(133,34,40,0.20)"/>
                <rect x="4"   y="22" width="22" height="14" rx="2" fill="rgba(133,34,40,0.40)"/>
                <rect x="28"  y="22" width="22" height="14" rx="2" fill="rgba(133,34,40,0.75)"/>
                <rect x="52"  y="22" width="22" height="14" rx="2" fill="rgba(196,154,42,0.50)"/>
                <rect x="76"  y="22" width="22" height="14" rx="2" fill="rgba(133,34,40,0.60)"/>
                <rect x="100" y="22" width="16" height="14" rx="2" fill="rgba(133,34,40,0.35)"/>
                <rect x="4"   y="38" width="22" height="14" rx="2" fill="rgba(196,154,42,0.45)"/>
                <rect x="28"  y="38" width="22" height="14" rx="2" fill="rgba(133,34,40,0.50)"/>
                <rect x="52"  y="38" width="22" height="14" rx="2" fill="rgba(133,34,40,0.85)"/>
                <rect x="76"  y="38" width="22" height="14" rx="2" fill="rgba(133,34,40,0.30)"/>
                <rect x="100" y="38" width="16" height="14" rx="2" fill="rgba(196,154,42,0.70)"/>
              </g>
            </svg>
          </div>
          <div class="v11-prog-header">
            <h3 class="v11-prog-title">部門別</h3>
            <span class="v11-prog-num" aria-hidden="true">05</span>
          </div>
          <p class="v11-prog-desc">部門 × 4軸のクロス分析。部門ごとの強み・弱みを比較し、個別施策の根拠データに。</p>
        </div>
      </div>

      <!-- Tab 06: 自由記述 -->
      <div class="v11-prog endock-tab">
        <div class="v11-prog-accent" aria-hidden="true"></div>
        <div class="v11-prog-body">
          <div class="endock-tab__chart" aria-hidden="true">
            <svg viewBox="0 0 120 60" width="100%" height="100%">
              <path d="M6 8 H56 a4 4 0 0 1 4 4 v14 a4 4 0 0 1 -4 4 H22 l-6 6 v-6 H10 a4 4 0 0 1 -4 -4 V12 a4 4 0 0 1 4 -4 z" fill="var(--color-primary-50)" stroke="var(--color-primary)" stroke-width="1"/>
              <line x1="14" y1="14" x2="50" y2="14" stroke="var(--color-primary)" stroke-width="1.5" stroke-linecap="round"/>
              <line x1="14" y1="20" x2="42" y2="20" stroke="var(--color-primary)" stroke-width="1.5" stroke-linecap="round"/>
              <path d="M64 26 H110 a4 4 0 0 1 4 4 v14 a4 4 0 0 1 -4 4 H100 l-6 6 v-6 H64 a4 4 0 0 1 -4 -4 V30 a4 4 0 0 1 4 -4 z" fill="var(--color-accent-50)" stroke="var(--color-accent)" stroke-width="1"/>
              <line x1="68" y1="32" x2="106" y2="32" stroke="var(--color-accent-light)" stroke-width="1.5" stroke-linecap="round"/>
              <line x1="68" y1="38" x2="96" y2="38" stroke="var(--color-accent-light)" stroke-width="1.5" stroke-linecap="round"/>
            </svg>
          </div>
          <div class="v11-prog-header">
            <h3 class="v11-prog-title">自由記述</h3>
            <span class="v11-prog-num" aria-hidden="true">06</span>
          </div>
          <p class="v11-prog-desc">従業員の生の声を「満足度が高いコメント」と「改善期待のコメント」に分類して表示。</p>
        </div>
      </div>

      <!-- Tab 07: 施策提案 -->
      <div class="v11-prog endock-tab">
        <div class="v11-prog-accent" aria-hidden="true"></div>
        <div class="v11-prog-body">
          <div class="endock-tab__chart" aria-hidden="true">
            <svg viewBox="0 0 120 60" width="100%" height="100%">
              <circle cx="14" cy="12" r="5" fill="var(--color-primary)"/>
              <polyline points="11,12 13,14 17,9" fill="none" stroke="#fff" stroke-width="1.5"/>
              <line x1="24" y1="12" x2="100" y2="12" stroke="var(--color-primary)" stroke-width="2" stroke-linecap="round"/>
              <circle cx="14" cy="30" r="5" fill="var(--color-primary)"/>
              <polyline points="11,30 13,32 17,27" fill="none" stroke="#fff" stroke-width="1.5"/>
              <line x1="24" y1="30" x2="92" y2="30" stroke="var(--color-primary)" stroke-width="2" stroke-linecap="round"/>
              <circle cx="14" cy="48" r="5" fill="none" stroke="var(--color-primary-200)" stroke-width="1.5"/>
              <line x1="24" y1="48" x2="80" y2="48" stroke="var(--color-primary-200)" stroke-width="2" stroke-linecap="round"/>
            </svg>
          </div>
          <div class="v11-prog-header">
            <h3 class="v11-prog-title">施策提案</h3>
            <span class="v11-prog-num" aria-hidden="true">07</span>
          </div>
          <p class="v11-prog-desc">診断データに基づき、御社に最適化した具体的な組織開発施策を 12 ヶ月の実施スケジュール案つきで提案。</p>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- 9. 調査の流れ（既存 .process__steps 流儀） -->
<section class="section section--gray" aria-labelledby="endock-process-title">
  <div class="container">
    <div class="section-header reveal">
      <p class="section-header__label">Process</p>
      <h2 class="section-header__title" id="endock-process-title">調査の流れ</h2>
      <span class="section-header__line" aria-hidden="true"></span>
      <p class="section-header__description">お申し込みからダッシュボード納品、施策提案まで、およそ <strong>4〜6 週間</strong> で完了します。</p>
    </div>
    <div class="process__steps reveal">
      <div class="process__step">
        <div class="process__step-number">01</div>
        <h3 class="process__step-title">事前ヒアリング</h3>
        <p class="process__step-text">部署構成・職位体系・調査目的を確認し、カスタマイズ箇所を特定。<br><small>所要：1〜2 日</small></p>
      </div>
      <div class="process__step">
        <div class="process__step-number">02</div>
        <h3 class="process__step-title">フォーム構築</h3>
        <p class="process__step-text">Web アンケートを構築。スマホ対応・完全匿名で率直な回答を促進。<br><small>所要：3〜5 日</small></p>
      </div>
      <div class="process__step">
        <div class="process__step-number">03</div>
        <h3 class="process__step-title">調査実施</h3>
        <p class="process__step-text">全従業員にメール等で案内し回答を収集。リマインド文面もご用意。<br><small>所要：1〜2 週間</small></p>
      </div>
      <div class="process__step">
        <div class="process__step-number">04</div>
        <h3 class="process__step-title">分析・納品</h3>
        <p class="process__step-text">回収データを集計・換算し、7 タブのインタラクティブダッシュボードを生成。<br><small>所要：1〜2 週間</small></p>
      </div>
      <div class="process__step">
        <div class="process__step-number">05</div>
        <h3 class="process__step-title">報告会・提案</h3>
        <p class="process__step-text">経営層・人事へ報告。データに基づく具体的な施策提案書を納品。<br><small>所要：90 分</small></p>
      </div>
    </div>
  </div>
</section>

<!-- 10. 施策メニュー（既存 .v11-programs 流儀） -->
<section class="section" aria-labelledby="endock-services-title">
  <div class="container">
    <div class="section-header reveal">
      <p class="section-header__label">Follow-up Services</p>
      <h2 class="section-header__title" id="endock-services-title">調査後の、具体的な施策メニュー</h2>
      <span class="section-header__line" aria-hidden="true"></span>
      <p class="section-header__description">endock の診断結果に基づき、組織開発の専門家が御社に最適な施策をご提案・実行します。</p>
    </div>
    <div class="v11-programs reveal">
      <div class="v11-prog">
        <div class="v11-prog-accent"></div>
        <div class="v11-prog-body">
          <div class="v11-prog-header">
            <h3 class="v11-prog-title">CMBO（目標管理制度）導入支援</h3>
            <span class="v11-prog-num">01</span>
          </div>
          <p class="v11-prog-desc">えんのした独自の Creative Management by Objectives。「やらされ目標」から「自分ごと化された目標」への転換を、対話型プロセスで実現します。</p>
          <div class="v11-prog-footer">
            <span class="v11-prog-tag"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>3〜6 ヶ月</span>
            <span class="v11-prog-tag"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/></svg>管理職・経営層</span>
          </div>
        </div>
      </div>
      <div class="v11-prog">
        <div class="v11-prog-accent"></div>
        <div class="v11-prog-body">
          <div class="v11-prog-header">
            <h3 class="v11-prog-title">リーダーシップ開発プログラム</h3>
            <span class="v11-prog-num">02</span>
          </div>
          <p class="v11-prog-desc">「課題形成 → 達成行動 → 信頼形成」の 3 軸モデルに基づく管理者行動の変容。座学＋職場実践＋コーチングの 6 ヶ月間で行動変容を定着。</p>
          <div class="v11-prog-footer">
            <span class="v11-prog-tag"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>6 ヶ月</span>
            <span class="v11-prog-tag"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/></svg>管理職</span>
          </div>
        </div>
      </div>
      <div class="v11-prog">
        <div class="v11-prog-accent"></div>
        <div class="v11-prog-body">
          <div class="v11-prog-header">
            <h3 class="v11-prog-title">レゴ®シリアスプレイ®ワークショップ</h3>
            <span class="v11-prog-num">03</span>
          </div>
          <p class="v11-prog-desc">言語化しにくい組織課題を「手で考える」ことで部門間の相互理解と共通ビジョンを構築。認定ファシリテーターが設計・進行。</p>
          <div class="v11-prog-footer">
            <span class="v11-prog-tag"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>1 日／2 日</span>
            <span class="v11-prog-tag"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/></svg>部門横断</span>
          </div>
        </div>
      </div>
      <div class="v11-prog">
        <div class="v11-prog-accent"></div>
        <div class="v11-prog-body">
          <div class="v11-prog-header">
            <h3 class="v11-prog-title">1on1 の質的向上プログラム</h3>
            <span class="v11-prog-num">04</span>
          </div>
          <p class="v11-prog-desc">国家資格キャリアコンサルタントの知見を活かし、「評価のための面談」から「成長のための対話」への転換を支援。</p>
          <div class="v11-prog-footer">
            <span class="v11-prog-tag"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>3 ヶ月</span>
            <span class="v11-prog-tag"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/></svg>管理職</span>
          </div>
        </div>
      </div>
      <div class="v11-prog">
        <div class="v11-prog-accent"></div>
        <div class="v11-prog-body">
          <div class="v11-prog-header">
            <h3 class="v11-prog-title">評価制度の運用改善</h3>
            <span class="v11-prog-num">05</span>
          </div>
          <p class="v11-prog-desc">制度そのものの再設計ではなく「運用」にフォーカス。評価者訓練、フィードバック面談の標準化、評価結果の透明性向上を支援。</p>
          <div class="v11-prog-footer">
            <span class="v11-prog-tag"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>6 ヶ月</span>
            <span class="v11-prog-tag"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/></svg>人事・管理職</span>
          </div>
        </div>
      </div>
      <div class="v11-prog">
        <div class="v11-prog-accent"></div>
        <div class="v11-prog-body">
          <div class="v11-prog-header">
            <h3 class="v11-prog-title">管理職育成プログラム</h3>
            <span class="v11-prog-num">06</span>
          </div>
          <p class="v11-prog-desc">全 12 回の体系的プログラムで次世代リーダーを育成。マネジメント基礎から戦略的思考まで段階的に習得。</p>
          <div class="v11-prog-footer">
            <span class="v11-prog-tag"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>12 回</span>
            <span class="v11-prog-tag"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/></svg>次期管理職</span>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- 11. 期待される成果（既存 .v11-outcomes ダーク） -->
<section class="section section--dark" aria-labelledby="endock-outcomes-title">
  <div class="container">
    <div class="section-header reveal">
      <p class="section-header__label">Outcomes</p>
      <h2 class="section-header__title" id="endock-outcomes-title">期待される成果</h2>
      <span class="section-header__line" aria-hidden="true"></span>
    </div>
    <div class="v11-outcomes reveal">
      <div class="v11-outcome">
        <div class="v11-outcome-icon" aria-hidden="true">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="23 6 13.5 15.5 8.5 10.5 1 18"/><polyline points="17 6 23 6 23 12"/></svg>
        </div>
        <p class="v11-outcome-text">組織課題が <span class="v11-outcome-highlight">8 カテゴリ</span> に分解され、優先順位が明確になる</p>
      </div>
      <div class="v11-outcome">
        <div class="v11-outcome-icon" aria-hidden="true">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M8 14s1.5 2 4 2 4-2 4-2"/><line x1="9" y1="9" x2="9.01" y2="9"/><line x1="15" y1="9" x2="15.01" y2="9"/></svg>
        </div>
        <p class="v11-outcome-text">経営層・人事・現場の <span class="v11-outcome-highlight">共通言語</span> ができ、対話の質が変わる</p>
      </div>
      <div class="v11-outcome">
        <div class="v11-outcome-icon" aria-hidden="true">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
        </div>
        <p class="v11-outcome-text">研修・施策の効果を <span class="v11-outcome-highlight">経年比較</span> で定量的に検証できる</p>
      </div>
      <div class="v11-outcome">
        <div class="v11-outcome-icon" aria-hidden="true">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/></svg>
        </div>
        <p class="v11-outcome-text">経営層への報告に、<span class="v11-outcome-highlight">客観的なデータ根拠</span> を持たせられる</p>
      </div>
      <div class="v11-outcome">
        <div class="v11-outcome-icon" aria-hidden="true">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="12 2 2 7 12 12 22 7 12 2"/><polyline points="2 17 12 22 22 17"/><polyline points="2 12 12 17 22 12"/></svg>
        </div>
        <p class="v11-outcome-text">組織開発の <span class="v11-outcome-highlight">PDS サイクル</span> が、データドリブンで回り出す</p>
      </div>
      <div class="v11-outcome">
        <div class="v11-outcome-icon" aria-hidden="true">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78L12 21.23l8.84-8.84a5.5 5.5 0 0 0 0-7.78z"/></svg>
        </div>
        <p class="v11-outcome-text">部門ごとの強み・弱みを把握し、<span class="v11-outcome-highlight">個別最適</span> な施策が打てる</p>
      </div>
    </div>
  </div>
</section>

<!-- 12. FAQ（既存 .v11-faq 流儀） -->
<section class="section" aria-labelledby="endock-faq-title">
  <div class="container container--narrow">
    <div class="section-header reveal">
      <p class="section-header__label">FAQ</p>
      <h2 class="section-header__title" id="endock-faq-title">よくあるご質問</h2>
      <span class="section-header__line" aria-hidden="true"></span>
    </div>
    <div class="v11-faq reveal">
      <details class="v11-faq-item">
        <summary class="v11-faq-q">
          <span class="v11-faq-q-badge">Q</span>
          <span>どのくらいの規模の企業が対象ですか？</span>
          <svg class="v11-faq-chevron" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="6 9 12 15 18 9"/></svg>
        </summary>
        <div class="v11-faq-a"><p>30 名規模の中小企業から、複数拠点をもつ中堅企業まで対応可能です。500 名超の規模については、設計段階から個別にご相談ください。</p></div>
      </details>

      <details class="v11-faq-item">
        <summary class="v11-faq-q">
          <span class="v11-faq-q-badge">Q</span>
          <span>回答にどれくらい時間がかかりますか？</span>
          <svg class="v11-faq-chevron" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="6 9 12 15 18 9"/></svg>
        </summary>
        <div class="v11-faq-a"><p>標準 60 問版で約 20 分です。負担を抑えたい場合は 40 問版（約 12 分）もご用意しています。スマートフォン対応で、通勤時間などにも回答できます。</p></div>
      </details>

      <details class="v11-faq-item">
        <summary class="v11-faq-q">
          <span class="v11-faq-q-badge">Q</span>
          <span>回答内容が誰に見られるか心配です</span>
          <svg class="v11-faq-chevron" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="6 9 12 15 18 9"/></svg>
        </summary>
        <div class="v11-faq-a"><p>完全匿名制です。個人を特定できる形で経営層・人事に共有されることはありません。集計は属性カテゴリ単位（部門・職位など）でのみ行います。</p></div>
      </details>

      <details class="v11-faq-item">
        <summary class="v11-faq-q">
          <span class="v11-faq-q-badge">Q</span>
          <span>料金はいくらですか？</span>
          <svg class="v11-faq-chevron" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="6 9 12 15 18 9"/></svg>
        </summary>
        <div class="v11-faq-a"><p>導入規模・調査範囲に応じた個別見積となります。おおよその目安は無料相談時にお伝えします。料金表のPDFは対面・オンラインミーティング時にご提示します。</p></div>
      </details>

      <details class="v11-faq-item">
        <summary class="v11-faq-q">
          <span class="v11-faq-q-badge">Q</span>
          <span>他社の従業員満足度調査と何が違うのですか？</span>
          <svg class="v11-faq-chevron" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="6 9 12 15 18 9"/></svg>
        </summary>
        <div class="v11-faq-a"><p>① 学術的根拠に基づく 60 問の体系的設問、② 報告書ではなくインタラクティブダッシュボードでの納品、③ 調査結果に基づく具体的な組織開発施策をえんのした自身が一気通貫で支援する点が大きな違いです。</p></div>
      </details>

      <details class="v11-faq-item">
        <summary class="v11-faq-q">
          <span class="v11-faq-q-badge">Q</span>
          <span>継続的に毎年実施できますか？</span>
          <svg class="v11-faq-chevron" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="6 9 12 15 18 9"/></svg>
        </summary>
        <div class="v11-faq-a"><p>可能です。むしろ、経年比較ができてこそ「施策の効果」が定量的に検証できます。2 年目以降は基本料金の 60% でリピート対応します。</p></div>
      </details>

      <details class="v11-faq-item">
        <summary class="v11-faq-q">
          <span class="v11-faq-q-badge">Q</span>
          <span>問い合わせ後にしつこく営業されませんか？</span>
          <svg class="v11-faq-chevron" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="6 9 12 15 18 9"/></svg>
        </summary>
        <div class="v11-faq-a"><p>ご安心ください。営業電話・しつこいご連絡はいたしません。お問い合わせの段階では「組織課題を一緒に整理する場」としてご活用ください。</p></div>
      </details>
    </div>
  </div>
</section>

<!-- 13. 締めの哲学引用 -->
<section class="section endock-philosophy" aria-label="えんのしたの哲学">
  <div class="container container--narrow">
    <div class="endock-philosophy__inner reveal">
      <div class="endock-philosophy__mark" aria-hidden="true">“</div>
      <blockquote class="endock-philosophy__quote">
        調査して、終わりではない。<br>
        データを「行動」に変える、<br>
        そこからが、私たちの仕事です。
      </blockquote>
      <div class="endock-philosophy__author">
        <span class="endock-philosophy__author-line"></span>
        <span>えんのした流・組織開発の哲学</span>
        <span class="endock-philosophy__author-line"></span>
      </div>
    </div>
  </div>
</section>

<!-- 14. CTA（既存テンプレートパーツ・他ページと完全統一） -->
<?php get_template_part('template-parts/section', 'cta'); ?>

</main>

<?php get_footer(); ?>
