# CLAUDE.md — endock LP（WordPressテーマ内）

このファイルは LP 専用フォルダ（`wp-content/themes/ennoshita/lp-endock/`）内の指示書です。
親フォルダの `CLAUDE.md`（テーマ全体の指示書）と併せて読まれます。

---

## 🎯 LP の方針（2026-05-03 v3 確定）

**既存サイトとの完全な統一感**と、**ビジュアルでの訴求力**を両立させる。

### 設計の柱

1. **既存テーマのコンポーネントをフル活用**
   - `get_header()` / `get_footer()` で既存のヘッダー・フッター・グローバルナビを継承
   - `.page-header` / `.section` / `.v11-overview` / `.v11-targets` / `.v11-programs` / `.v11-outcomes` / `.v11-faq` / `.process__steps` / `.trust__grid` / `.btn` 等、既存 `style.css` の磨かれたコンポーネントを再利用
   - `template-parts/section-cta.php` は既存テンプレートパーツを流用

2. **LP固有の追加要素**は独自に実装
   - **4 軸 × 8 カテゴリ同心円図**（SVG・自前作成）
   - **ダッシュボード実物プレビュー**（iframe で `lp-endock/dashboard-sample.html` を埋め込み・74KB・Chart.js 動作）
   - これらは `lp-endock/lp-endock.css` で `.endock-` プレフィックスで定義（既存クラスと衝突しない）

3. **既存サイトに溶け込む**
   - `<body class="lp-endock">` のスコープ分離は使わない（既存スタイルに依存するため）
   - 代わりに `.endock-` プレフィックスで衝突回避
   - 色・フォント・余白・角丸・シャドウは既存 `:root` 変数（`--color-primary`, `--color-accent` 等）をそのまま参照

---

## 🔒 触らないファイル（不可侵）

- ❌ `style.css`（87KB・既存テーマの心臓）
- ❌ `footer.php`
- ❌ `functions.php`
- ❌ 既存 `page-*.php`（page-about, page-service, page-contact 等）

## ✏️ 最小限の追記をしたファイル

- `header.php` — フォールバックメニューのサブメニューに endock を追加（NEW バッジ付き）
- `front-page.php` — 「実績」セクション直後に endock 誘導セクションを挿入（既存 `.section` 等のクラスとインラインスタイルのみ）

---

## 🏗️ ファイル構成

```
wordpress-theme/ennoshita/
├── page-endock.php                ← LP テンプレート本体
└── lp-endock/
    ├── CLAUDE.md                  ← このファイル
    ├── README.md
    ├── lp-endock.css              ← LP固有の追加スタイルのみ（.endock- プレフィックス）
    ├── tokens.css                 ← （旧版・現在は未使用、互換のため保持）
    ├── dashboard-sample.html      ← サンプルダッシュボード（iframe埋め込み用・74KB）
    └── assets/
        ├── logo-primary.png       ← （未使用・予備）
        └── images/
```

---

## 📑 LP セクション構成（13セクション）

すべて既存 `style.css` のクラスを使用（指定がないものは既存）。

1. **ページヘッダー**（`.page-header` ダーク背景）— ラベル・タイトル・サブタイトル
2. **パンくず**（`ennoshita_breadcrumb()`）
3. **統計バー**（`.section--dark` + `.trust__grid`）— 60問・8カテゴリ・4軸・7タブ（カウントアップ）
4. **endock とは**（`.section` warm + `.v11-overview`）— リード+本文 + 特長アイコン4つ
5. **こんな課題**（`.section--gray` + `.v11-targets`）— チェックアイコン6項目
6. **4軸 × 8カテゴリ図解**（`.section` + 独自 `.endock-orbit`）— SVG 同心円図 + 凡例
7. **🌟 ダッシュボード実物プレビュー**（`.section--dark` + 独自 `.endock-dashboard`）— iframe
8. **7 タブ解説**（`.section` + `.v11-programs`）— アクセントバー付きカード × 7
9. **調査の流れ**（`.section--gray` + `.process__steps`）— 5ステップ
10. **施策メニュー**（`.section` + `.v11-programs`）— カード × 6
11. **期待される成果**（`.section--dark` + `.v11-outcomes`）— ハイライト6項目
12. **FAQ**（`.section` + `.v11-faq`）— 7問
13. **CTA**（`template-parts/section-cta.php`）— 他ページと完全統一

---

## 🚫 やってはいけないこと

- ❌ 既存 `style.css` への変更
- ❌ サンプルダッシュボード（`dashboard-sample.html`）の中身を編集
- ❌ 料金表の掲載（対面営業時にPDFで提示する方針）

---

## ✅ 公開後のチェックリスト

- [ ] PCブラウザで表示確認（Chrome / Safari / Firefox）
- [ ] スマホ表示確認（iOS Safari / Android Chrome）
- [ ] iframe 内のサンプルダッシュボードが動くか
- [ ] 既存ページ（about/service/contact）の表示に影響が出ていないか
- [ ] WP管理画面で固定ページ作成（slug: `endock`、テンプレート: `endock LP`）
- [ ] WP管理画面 → 外観 → メニュー → サービスサブメニューに endock を追加

---

## 🌟 endock の意味（覚え書き）

- **en** = 縁（えん）／ 株式会社えんのしたの「えん」
- **dock** = 船舶のドック・人間ドック → **健康診断**のメタファー

→ 「組織の健診ステーション」というブランドイメージ。
